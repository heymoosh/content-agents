# Venture Build v7 — backend handoff (sanity check against `heymoosh/content-agents`)

Design: `Venture Build v7.dc.html`. Repo checked live at commit `5700a2c167a4` (branch `main`).
This supersedes `Venture Build v5 - backend handoff.md` for the Venture room (that document's
§1–§9 still hold — read it first) and adds three rooms v5 didn't cover in detail: the v7
conversational-thread mechanics, the rebuilt Outreach room, and Fiction's inline canon-fix. Signals
turns out to need a bigger rebuild than v5 implied.

**Method.** Read the real source for each room the prototype assumes data from — `src/outreach/*`,
`src/fiction/canon.ts`/`draft.ts`, `src/review/signals.ts`, `docs/venture-schema-contract.md` — and
checked every UI assumption against it. Below: what already matches (build against it as-is), and
what the prototype is inventing that has no backend yet.

---

## 1. Venture room additions — mostly already specified, two real gaps

**Matches, no new work needed:**
- Checkpoint verification badges (LINK ↗ / SYSTEM ▪ / YOUR WORD ✓) map directly to
  `evidence.type` (`url` / `agent` / `attestation`) in `venture-schema-contract.md` §4. Render
  from that field; nothing to add.
- The override-reason interrupt (Confirm disabled until a reason is typed) matches
  `decisions.jsonl`'s `override_reason` (§2A) exactly — required whenever `selected_candidate_id`
  differs from `recommended_candidate_id`. Already specified in v5 handoff §9.2.

**Gap — live autosave has no endpoint.** The prototype debounces every keystroke to a "saving…
saved" indicator. `venture/intake.ts` is a batch script that writes a completed answer per
question; nothing in the repo persists a partial, in-progress answer. Needed: a small
`PATCH /api/venture/:slug/intake/:n/draft` (or equivalent) that the GUI can hit on a debounce,
separate from the final `POST` that advances `intake.md`. Low-risk addition, no schema change.

## 2. Fiction room — the inline "Fix the line" has nothing to call

The prototype's canon rail lists holds/conflicts and a **Fix the line** button that rewrites the
flagged sentence inline in the purple draft. Checked `src/fiction/canon.ts` and `draft.ts`:

- `canon.ts` is a write-only ledger — it appends a continuity summary *after* Muxin approves a
  chapter. It does not check a draft against canon, and there is no conflict-detection step
  anywhere in `src/fiction/`.
- `draft.ts` generates a whole chapter in one pass. There is no operation that patches one sentence
  of an existing draft and re-saves it.

**Gap, real:** two missing pieces —
1. A continuity-check step (reads `canon.md` + `characters/*.md` against a fresh draft, returns
   holds/conflicts, ideally via the `STEP n/total` marker protocol from v5 handoff §1 so it shows
   as its own job).
2. A scoped patch operation — "replace this span with this text, re-save the chapter draft" — for
   Fix the line to call. Today the only write path is the full `draft.ts` regeneration.

The second-pass job ("More tension, less explaining" as its own measured job, not an instant
rewrite) has no backend counterpart either, but is the same shape as v5 handoff §1's `steps[]`
work — no new design needed, just wire fiction's draft-revise path through it.

## 3. Outreach room — rebuilt to a shape the backend doesn't have yet

This is the biggest gap. `src/outreach/{draft,lock,qualify,status}.ts` model a **pipeline**
(research → qualify → draft → lock), not the **live co-drafting conversation** v7 renders. Detail:

| Prototype assumes | Repo actually has | Gap |
|---|---|---|
| Picking a contact opens a thread; the AI asks a direction question live | `draft.ts`'s `pitch_angle` is set upstream by `research.ts`/qualify, baked into `lead.md` frontmatter before drafting ever runs | No endpoint takes typed direction text and feeds it into that run's draft prompt |
| Feedback rewrites the **same** draft in place | `draft.ts` always writes a new numbered file (`message-01.md`, `message-02.md`, …) — there's no revise-in-place operation (unlike Atomize's `revise.ts` for content) | Needs an outreach equivalent of the revise skill, or the GUI must accept "new message per iteration" and hide the seams |
| One `toName`/`toNote` per contact | `readLeadDetail()` returns a `contacts: Contact[]` array (`{name, role}`), plus `suggestedContacts` pulled from evidence | Render the contacts array; a lead can have 0, 1, or several — "no named contact yet" is the 0-contact case, not a special flag |
| Three segments: Platforms / Mission fit / Open roles | `lead.md` already carries `segment: "platform" \| "org-role" \| "org-mission"` — same three buckets, different string values | Just a naming map, no gap |
| Claims render a quote+source, or a date if no URL | `EvidenceItem` has `source` (URL or `vault:<path>`) and `quote`, but **no timestamp field at all** | "observed Aug 6" has nothing to read from — either add a `captured_at` to evidence items, or drop the date fallback and require a source always |
| Lock → Copy to clipboard + Mark as manually sent (separate steps) | `lock.ts` sets `status: locked` and writes one decision-log line; that's the terminal state — there's no post-lock "confirm it actually sent" step the way Venture's `live_confirmed` works | Worth a product decision: should Outreach get the same locked-vs-sent split Venture has for approved-vs-live? Today locking *is* "done." |
| "Suggested angle" opening line, generated per contact | `matchmaker.ts` already writes `why_them`/`why_me`/`why_mutual` per lead via its own LLM pass | Good match — the AI's opening line should be built from these three fields, not invented fresh |

**Net:** the segmentation, the why-them/why-you/mutual-fit grid, and the evidence rail are all real
fields already produced by the pipeline (`readLeadDetail`) — build the static parts against those
as-is. The conversational parts (live direction input, in-place revise) are new: either build a
thin live-draft endpoint that wraps `draft.ts` with a direction parameter and a revise mode, or
scope v1 to "direction sets `pitch_angle` before the first draft only" and accept that "iterate" is
really "draft again," numbered underneath.

## 4. Signals room — reads the wrong data source entirely

The prototype's four kept-apart outcome families (Attention / Conversation / Audience / Business,
each with a sample-size threshold and a pre-launch "NOTHING LIVE YET" state) do not exist in
`src/review/signals.ts`. What that file actually does:

- `readSignals()` parses the **latest dated strategy brief** (`briefs/YYYY-MM-DD-strategy-brief.md`)
  for two sections: a per-channel **data-confidence table** (`posts`, `weeks`, `status` — this is
  the real fix for the design system's own flagged bug, a channel with 13 weeks of data getting
  equal visual weight to one with 52) and a list of **DO MORE / TEST / DO LESS** recommendations.
  Completely different shape from "four families."
- The four-family model the prototype renders is speced only in prose, in
  `venture-schema-contract.md` §5.8 / `venture/rules.md`, and explicitly **not built** —
  `docs/venture-build-plan.md`'s Model notes call it out directly: *"Adding the redacted
  research-observation read to Signals is new work, tracked as Card D in the backlog proposal."*
- `appendBacklogCard()` is real and matches the "adopt" action's intent, but not its copy. It
  **files a `prose_kanban` card to `docs/content-agents-backlog.md`**, deduped by title, and — its
  own comment says — *"the conductor pipeline's grooming decides everything after that."* It is not
  an immediate config write. The prototype's "Rule added. Applies to next post." overstates what
  actually happens today.

**Gap, real:** Signals needs its four-family read built (Card D) before this room can render as
designed — it isn't a wiring gap, it's an unbuilt feature. Until then, two options: build Card D
first, or ship the room against what `readSignals()` already returns (channel confidence + DO
MORE/TEST/DO LESS) and hold the four-family redesign for after Card D lands.

**Copy fix needed regardless of Card D:** change "Rule added. Applies to next post." to something
honest about the real mechanism, e.g. "Filed to the backlog. It's picked up and applied from
there" — match `appendBacklogCard`'s actual behavior, not an invented instant-apply.

---

## 5. Priority order for Claude Code

1. Outreach's static reads (segments, contacts, why-fit grid, evidence) — zero backend work,
   `readLeadDetail()` already returns everything. Do this first; it's most of the room.
2. Signals copy fix (§4's "Rule added" wording) — one string, ships today regardless of Card D.
3. Fiction's continuity-check + scoped patch (§2) — blocks "Fix the line" specifically; the rest of
   Fiction (composer, locked beats, second-pass-as-job) already has a home in v5 handoff §1.
4. Venture's live-autosave endpoint (§1) — small, additive.
5. Outreach's live-direction + in-place-revise (§3) — the real product decision: build it, or
   descope to "draft again" and let the GUI hide the seam.
6. Signals' four-family read (Card D) — the only genuinely unbuilt feature here; largest lift,
   lowest urgency (the room can ship against the real `readSignals()` shape first).

## 6. What did NOT change from v5

Everything in `Venture Build v5 - backend handoff.md` §0–§9 still applies unchanged: the job queue
(`steps[]`, `blocked`+`ask`, `retryable`), the Venture state machines, the checkpoint/decision-record
model, and the room-by-room rules in its §6–§7. This document only adds what v6/v7's new screens
(conversational thread mechanics, Outreach redesign, Fiction inline fix, Signals rework) assume
that v5 didn't have reason to check yet.
