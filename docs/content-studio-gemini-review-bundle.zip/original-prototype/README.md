# Content Studio — front-end handoff package

Everything Claude Code needs to build the real front end to match the prototype exactly.
Repo: heymoosh/content-agents, branch main, checked at commit 5700a2c167a4.

## Read in this order

1. **Venture Build v7 - backend handoff.md** — START HERE. The sanity check of the prototype
   against the real repo: what already has data, what is missing, what copy overstates the
   backend, and a priority order. Written after reading src/outreach/*, src/fiction/canon.ts +
   draft.ts, src/review/signals.ts, and docs/venture-schema-contract.md live.
2. **Venture Build v5 - backend handoff.md** — still current for everything v7 didn't revisit:
   the job queue (steps[], blocked+ask, retryable, publicJob additions), the Venture two state
   machines, checkpoints, decision records, and the room-by-room rules. §0 lists what already
   exists and must not be rebuilt.
3. **Venture Build v7.dc.html** — the prototype itself, and the visual/behavioral reference.
   Open it in a browser (needs support.js next to it, included). Every room is live and
   clickable; the "Dev key" button bottom-right jumps to any state (checkpoint cleared, job
   failed, phase 3 gate, etc.) so you can see each screen without playing through.
4. **content-studio-vision.md** — the product frame: five rooms, what each is for.
5. **github.md** — the repo sync record: what was read, gaps found, and a screen-to-source map
   (which repo files each prototype screen is built from).

Interface copy is not a separate file: the authored strings live in the prototype itself and should
ship verbatim. They follow config/voice.yaml (written to Muxin, active voice, no em dashes, no AI
tells, the word "atomize" never appears in the UI).

## How to read the prototype file

It is one self-contained page: a template (markup, inline styles only) plus one logic class at
the bottom of the file, inside <script type="text/x-dc">. No build step, no npm install.

- Rooms are the top-level <sc-if> blocks: Studio, Venture, Content, Outreach, Fiction, Signals.
- All styling is inline. Colors that matter: walnut desk #231508, paper #fbf9f4, ink #1c1a17,
  Muxin's blue #2f5d9a, AI purple #5b46b8, amber #9a6b12, green #2f7d46, red #9a2f2f.
- The type convention is load-bearing: Georgia serif means the words are Muxin's, sans means the
  app is talking, purple means an AI wrote it, mono 10-11px uppercase is for rails and chips only.
- State lives in the logic class's state object; every screen is derived from it in renderVals().
  Read the *Vals() methods (outreachVals, signalsVals, sceneVals, cpVals, contentVals) — each one
  is effectively the API response shape that screen needs.

## The rules that must survive the port

1. Nothing publishes or sends without an explicit human action. Say so once, in place.
2. Approved and live are different states. One green check for both is wrong.
3. Never show a duration, count, or rate the system did not measure.
4. Muxin's words and AI-proposed words stay visually unmistakable.
5. A blocked job releases the job lane.
6. Every claim about a contact carries a source or the date it was observed.
