# Venture Build v5 — backend handoff

Design reference: `Venture Build v7.dc.html` (this package). Repo: `heymoosh/content-agents`,
branch `main`.

This document covers **only what does not exist yet** in the job/venture layer. Everything else in
the prototype renders state the repo already produces. Read §0 before estimating: most of the job
machinery is built, and two of the four items below are small. Read
`Venture Build v7 - backend handoff.md` alongside it — that one covers the newer rooms (Outreach
rebuild, Fiction inline canon-fix, Signals) and the v7 thread mechanics.

---

## 0. What already exists, and must not be rebuilt

`src/review/jobs.ts` is the single job queue for every Claude-spawning GUI action. It already has:

| Thing | Where | Notes |
|---|---|---|
| One serialized lane | `draining` mutex in `drain()` | Exactly one job runs at a time, GUI-wide |
| 19 job kinds | `type JobKind` | `url file text notes continue video develop develop-reply revise brief-revise insights ask-insights duplicate draft-follow-up pull strategy scout charles-draft` |
| Four statuses | `type JobStatus` | `queued \| running \| done \| failed` |
| Real elapsed time | `jobElapsedMs()` | Ticks while running, freezes at `finishedAt` |
| Heartbeat | `job.lastStdoutLine` | Last non-empty stdout line, updated as output streams |
| Per-job log | `jobLogPath(id)` | `~/.content-agents/logs/gui-jobs/<id>.log`, append mode |
| Failure decoding | `decodeSpawnFailure()` | ENOENT / timeout / non-zero exit, three distinct messages |
| Artifact verification | `runVideoJob`, `runDevelopJob`, `runContinueJob`, `drain()` | "finished" != "worked" — checks the artifact, not the exit code |
| Bounded log tail on failure | `logTailSuffix()` | Last 30 lines appended to `job.error` |
| The polled read shape | `publicJob()` | Explicit allowlist. This is what a screen gets |
| Idempotent enqueue | `addVideoJob`, `addDevelopFolderJob` | Double-click returns the in-flight job |
| Stdout marker parsing precedent | `parseReviseRefusal()` | Parses a `REFUSED:` line out of stdout. **Follow this pattern for §1.** |

The prototype's Studio working panel, in-room progress strips, and team rail are all drawn against
`publicJob()`. Do not change that function's existing fields.

---

## 1. NEW — ordered steps (`steps[]`)

**Why.** The only progress signal today is `lastStdoutLine`, a free-form heartbeat. Muxin asked for
an ordered checklist so she can confirm a job followed the right sequence and see *where* it broke.
A heartbeat cannot do that.

**Protocol.** Skills emit a step marker on stdout. The runner parses it, exactly as
`parseReviseRefusal` already parses `REFUSED:`.

```
STEP <n>/<total> <label>
```

Examples a skill would emit:

```
STEP 1/3 Read your beats
STEP 2/3 Checked them against the canon
STEP 3/3 Drafted the scene
```

Rules for the marker:

- Emitted on its own line, to stdout, before the step's work begins.
- `<n>` is 1-indexed. `<total>` is fixed for the run and declared on step 1.
- `<label>` is prose, written to Muxin, sentence case, no trailing period, under ~48 chars.
  It says what the step **did or is doing**, never a component name.
- A skill that emits no markers keeps working exactly as today — `steps` stays empty and the UI
  falls back to the heartbeat line. **This must not be a breaking change for the other skills.**

**Parser.** New exported pure function next to `parseReviseRefusal`, unit-testable without a spawn:

```ts
export function parseStepMarker(line: string): { n: number; total: number; label: string } | null
```

Wire it into `runCommandSpawn`'s `onChunk` alongside the existing `lastNonEmptyLine` heartbeat
update — same buffer, one extra check per chunk. Split the incoming text on newlines so a chunk
containing several markers advances to the last one.

**Job fields.**

```ts
steps: string[];        // labels, in order, filled as markers arrive (length grows to `total`)
stepTotal: number | null;
step: number;           // count COMPLETED — 0 before the first marker
```

`step` advances when marker `n` arrives, meaning steps `1..n-1` are done and `n` is in flight.
On a clean finish set `step = stepTotal`.

**Which skills to instrument first**, in order of value: `develop`, `atomize`, `venture`, `outreach`,
`story`. The other nine can follow later or never.

---

## 2. NEW — a job that stops and asks (`blocked` + `ask`)

**Why.** A run that needs one decision currently has two bad options: guess, or fail. Muxin's ask
was that it "asks me for what it needs to proceed".

**Status.** Add a fifth value:

```ts
type JobStatus = "queued" | "running" | "blocked" | "done" | "failed";
```

**Field.**

```ts
ask: { question: string; options: string[]; askedAt: number } | null;
answer: string | null;
```

`question` is one sentence, written to Muxin, ending in a question mark. `options` is 2 or 3 short
labels. No free-text asks in v1 — the prototype's chips are the whole interaction.

**Protocol.** Same stdout-marker approach:

```
ASK <question>?
ASK-OPTION <label>
ASK-OPTION <label>
```

The subprocess then **exits 0** after printing them. It does not wait. This matters: a held-open
subprocess would occupy the lane and burn the 15-minute timeout on a human's response time.

**⚠ The lane consequence — this is the real design decision.**

`drain()` holds `draining` for the duration of a job. If a blocked job kept the lane, one
unanswered question would stall every other queued job behind it. So:

1. On `blocked`, set `finishedAt`, release `draining`, and call `drain()` for the next job.
2. `jobElapsedMs` must treat `blocked` like `done` — the clock freezes at the point it asked.
   The prototype does this: a blocked job shows a frozen elapsed, not a running one.
3. On answer, **requeue as a new job** carrying the answer forward, rather than resuming the
   original. Set `status: "queued"`, `startedAt: null`, and pass the answer into the next spawn's
   prompt. Resuming a dead subprocess is not possible and should not be faked.
4. A blocked job is not finished work: `clearFinishedJobs()` must keep clearing only `done` and
   `failed`, never `blocked`.

**Route.** `POST /api/jobs/:id/answer` with `{ answer: string }`. Guard: only from `blocked`, and
`answer` must be one of the recorded `options`.

---

## 3. NEW — `publicJob` additions

Additive only. Existing fields unchanged.

```ts
export function publicJob(j: Job) {
  return {
    // ... every existing field, untouched ...
    steps: j.steps,
    stepTotal: j.stepTotal,
    step: j.step,
    failedAtStep: j.failedAtStep,   // index of the step that died, or null
    retryable: j.retryable,         // see §4
    ask: j.ask,
    answer: j.answer,
    logPath: jobLogPath(j.id),      // the UI shows this; today it is not exposed at all
  };
}
```

`logPath` is required — the design pairs elapsed time with a log link, and the prototype renders
the path in mono. Without it the link is a dead `href="#"`.

---

## 4. NEW — `retryable`, and which step died

Failure handling exists and is good. Two gaps:

- **`failedAtStep`.** Set it when a job fails, from the current `step`. The UI puts a red dot on
  that step and leaves the earlier ones green — "Drafted the scene" going red while
  "Checked them against the canon" stays green is the whole point of the checklist.
- **`retryable`.** The venture artifact side already gates its Retry action on
  `failure.retryable` (`docs/venture-schema-contract.md` §4.1). Jobs have no equivalent, so the UI
  cannot decide whether to offer Retry. Derive it in `decodeSpawnFailure`:

| Failure | `retryable` | Why |
|---|---|---|
| timeout | `true` | May succeed with less input or a quieter machine |
| non-zero exit | `true` | Usually transient |
| artifact check failed (ran, wrote nothing) | `true` | Worth one more attempt |
| ENOENT (`claude` not on PATH) | **`false`** | Retrying cannot fix a missing binary |

Retry sets `status: "queued"`, clears `error`/`failedAtStep`/`step`, keeps the same job id so the
log appends. Route: `POST /api/jobs/:id/retry`, guarded on `retryable`.

---

## 5. The UI contract — every state, with its copy

The prototype is the reference. Copy below is authored and should ship as-is; it follows
`config/voice.yaml` (written to Muxin, active voice, no em dashes, no AI tells).

### 5.1 Job row states

| `status` | Rail label | Clock | Step dots | Footer |
|---|---|---|---|---|
| `queued` | `Waiting its turn`, grey | `N ahead of it` | all grey, muted text | "One job runs at a time, so this starts when the one above finishes." |
| `running` | `Working`, purple | real elapsed, ticking | done green, current purple, rest grey | the heartbeat line, verbatim |
| `blocked` | `Needs you`, amber | frozen elapsed | current step amber | "It stops here until you answer. Nothing is written in the meantime." |
| `failed` | `Did not work`, red | `stopped after 3s` | failing step red, earlier green, later grey | "It stopped where the red dot is. Nothing was written." |
| `done` | the room name, green | `took 3s` | all green | the landing sentence (§5.3) |

Colors: purple `#5b46b8` (AI register), amber `#9a6b12`, green `#2f7d46`, red `#9a2f2f`,
grey `#d8d2c6`. Progress bar fill = `step / stepTotal`.

**One rule, learned the hard way in review: never render a duration the system did not measure.**
Every elapsed value comes from `elapsedMs`. There is exactly one place per job where a duration
appears. A frozen literal next to a live counter is the defect this design was corrected for four
times.

### 5.2 Where a job appears

Three surfaces, one source:

1. **Studio working panel** — every job, newest first. Text, rail, clock, step list, ask or failure
   box, `Watch it in <Room>` / `Read it in <Room>`, the log path in mono, `Stop it`.
2. **The destination room's progress strip** — top of Content, Outreach, Fiction, Signals. Same
   data, and it **lingers 9 seconds after finishing** so arriving late still shows what happened,
   then clears. Without this, "Watch it in Fiction" leads to a room that looks idle.
   (v7 exception: on a Fiction job failure the strip is suppressed, because Fiction now renders its
   own localized failure log next to the composer — one failure card per screen, never two.)
3. **Studio's team rail** — one row per live job, named per room: Fiction→Co-writer,
   Content→Formatter, Outreach→Connector, Signals→Reader, Venture→Build. Header is
   `YOUR TEAM, WAITING ON YOU` if any job is blocked, else `WORKING` if any is running, else `IDLE`.
   Resting rows (Scout, Publisher, Illustrator) are filtered against live rows by name so no agent
   ever appears twice.

### 5.3 Landing sentences, per room

Shown on `done`. These state what is waiting, never that something published.

- Fiction: "A scene draft, waiting on your read."
- Content: "A cut, waiting on your yes."
- Outreach: "A message, locked only when you say so."
- Signals: "Filed. It writes nothing."
- Venture: "An answer in the build conversation."

### 5.4 Capture routing

Studio's capture box routes text to a room by keyword, then starts a job. Routing is a **guess that
is cheap and reversible** — it is stated, not hidden, and filing never publishes anything.

| Match | Room |
|---|---|
| `http`, `.com`, `.ai`, `.org` | Signals |
| `follow up`, `reply to`, `email`, `intro`, `reach out`, `met ` | Outreach |
| `chapter`, `scene`, `elias`, `character`, `plot` | Fiction |
| `price`, `offer`, `landing`, `magnet`, `survey`, `venture`, `phase`, `response`, `repl` | Venture |
| anything else | Content |

Server-side this should become a small classifier, but keep the behaviour: pick one room, say which,
start one job, change nothing else.

---

## 6. Room behaviour the backend must support

**Fiction.** Opens on a composer, "What happens next?", empty. Muxin types beats, presses
`Draft it`, a job runs, the scene renders below with her beats kept in place above it as a
read-only anchor. Second pass ("More tension, less explaining") is **its own job** with its own
measured clock, not an instant rewrite. The canon rail runs continuity checks; a conflict offers
`Fix the line`, which rewrites the prose in place ("his gloved hand" → "his two remaining fingers",
per chapter one). Header tracks state: unwritten → drafting → scene waiting on you → nothing
written (on failure). See `Venture Build v7 - backend handoff.md` §2 — the continuity check and the
scoped patch do not exist yet.

**Venture.** The full 14-day flow: 25-question intake, phases 1–4, checkpoints 1–3, Day 14 review.
Renders `docs/venture-schema-contract.md` unchanged — the two state machines stay separate,
`approved` never displays as `live`, evidence renders by type (URL as a link, attestation as "you
confirmed this on Aug 12", agent as its own fact), retraction keeps the original evidence.

**The response gate is the one place a job must refuse.** A capture about survey responses checks
for a `survey` artifact with `delivery_status === "live_confirmed"`. If there is none, the job comes
back with "Nothing counted. The survey goes live in Phase 2, and until it is live there is nowhere
for responses to come from." It must never invent a respondent count — per §5.4 of the contract the
count is eligible unique respondents, deduped by respondent hash, and a fabricated one would arrive
at the Phase 3 gate pre-satisfied.

**Content.** Receives a Venture post only once it is confirmed live on Substack, then makes
per-platform versions, each needing her yes. Backed by `src/publish/queue.ts`, `src/review/rows.ts`.

**Outreach.** Shows who, why they are the contact, and when it was pitched. The action is
`Lock this message` with "Locking readies it. You send it by hand." **Not** approve-and-send.
Backed by `src/outreach/lock.ts`, `draft.ts` — and see the v7 handoff §3, which rebuilt this room
as a triage/co-drafting split.

**Signals.** Every rate carries its sample size. A thin sample renders dimmed with a plain caveat
("21 impressions. Too thin to act on, and it is only here so you can watch it."). Before Phase 2 the
probe block reads `NOTHING LIVE YET` and says why, rather than showing zeros. Backed by
`src/review/signals.ts` — but see v7 handoff §4: the four-family model is not built there yet.

---

## 7. Rules that must hold

1. Nothing publishes or sends without an explicit human action. Say so once, in place.
2. Approved and live are different states. One green check for both is wrong.
3. Never show a duration, count, or rate the system did not measure.
4. Muxin's words and AI-proposed words stay visually unmistakable. Georgia serif is hers,
   sans is the app, purple `#5b46b8` is AI-written.
5. Filing routes. It never publishes.
6. A blocked job releases the lane.
7. Interface copy: written to Muxin, active voice, no em dashes. The word "atomize" never appears
   in the UI.

---

## 8. Open decisions for Muxin

1. **Requeue-on-answer vs. true resume** (§2). Requeue is proposed because a subprocess cannot be
   resumed. It means the answer is passed into a fresh prompt, so the job runs its early steps again.
   Acceptable, or should blocked jobs checkpoint their work first?
2. **Which skills emit step markers**, and who writes the labels. Proposed: the skill author, since
   the labels are the skill's own sequence.
3. **Free-text asks.** v1 is chips only. Some questions ("which of these three angles") do not fit
   2–3 fixed options.
4. **Server-side capture classification** (§5.4) — keyword list, or a small model call?

---

## 9. What the venture plan added after the first handoff

Nine items, all built in the prototype. Ordered by backend consequence.

### 9.1 Phase 1 has three artifacts before an idea is drafted

Flow: platform pick → **research plan** → ideas → Checkpoint 1 → **research read** →
**continuation decision** → Phase 2.

`phase_1_research_plan` — confirmed knowns each carrying an evidence reference, open unknowns tagged
by dimension, and probes each tying one candidate idea to one unknown. **One probe per unknown**: the
prototype flags a duplicate as `TESTS U-1 · ALREADY COVERED` in amber, because two probes on one
unknown cannot be attributed. Muxin reviews it, and ideas are not generated until she does.

`phase_1_research_read` — findings, each `planned` or `emergent`. A planned finding answers a
declared unknown. An **emergent finding requires an explicit accept before anything downstream reads
from it**; declining keeps it visible as observed and wires it to nothing. Backend: a
`findings[].accepted: boolean | null` field, and Phase 2 generation must filter on `accepted === true`.

`phase-1-research-continuation` — a three-way decision, and **Phase 2 must not start until it is
recorded**: `more_probes` (timeline shifts, and the shift is stated), `proceed_on_evidence`, or
`proceed_as_hypothesis` (every downstream artifact leaning on the thin unknown carries the word
hypothesis). Store as a decision record per §9.2.

### 9.2 Decision records, and the control that reads them

Every judgment step writes: candidates, per-candidate scores, evidence references, the
recommendation with its rationale, the selection, and an **override reason when the selection differs
from the recommendation**. The prototype renders this behind one "Why these three" link, and the
override reason is **required** — the confirm button is `disabled` until a reason is typed, then the
record reads back with the rules version stamped beside it.

```ts
type DecisionRecord = {
  step: string;                  // "1.2", "2.1", "3.5"
  candidates: { id: string; scores: Record<string, number>; evidence: string[] }[];
  recommended: string[];
  rationale: string;
  selected: string[];
  overrideReason: string | null;  // required iff selected !== recommended
  rulesVersion: string;
  at: number;
};
```

### 9.3 The response gate and Phase 3 completion are separate events

`response_gate_opened` fires at 20 eligible unique respondents and unlocks the cluster, problem,
outline and price analysis **only**. It must never block posting. `phase_3_completed` requires
problem, transformation, outline, price and **pitch** all approved, and that is what unlocks Phase 4.

`pitch` is a new artifact kind, `delivery_mode: none`. It composes from the four artifacts above it
rather than introducing new claims.

**Watch the checkpoint-3 code paths.** Wiring a third checkpoint activated two branches written when
only 1 and 2 existed, and both were wrong: a two-way `if/else` sent checkpoint-3 into checkpoint-2's
handler (moving the venture backwards a phase), and a `"Phase " + (n + 1)` string claimed Phase 4
would open when it already had. Any code branching on checkpoint number needs an explicit third case.

### 9.4 Checkpoint 2's five named conditions

Not generic artifact rows — five specific live checks, each with its own failure sentence:
magnet downloadable, landing page stores an email, survey stores an answer **against the subscriber**,
welcome email active and delivering the magnet, announcement **optional**. The rail counts required
conditions only, derived from an `optional` flag, so it can never render "5 of 4". In v7 each row
also renders two separate facts — the approval stamp and the live state — plus a verification badge
(LINK / SYSTEM / YOUR WORD) read from `evidence.type`.

### 9.5 The survey is a fit review, not authoring

Muxin already has a live 4-question branching survey. Phase 2's job is to review its **fit against the
chosen magnet** and recommend edits only where fit breaks — not to draft a replacement.

### 9.6 Evidence roles, derived not declared

`historical_prior` | `current_probe` | `current_organic`. Derive from when and how the evidence
arrived; never let a caller declare it. **Historical evidence counts toward the research read and
never toward Checkpoint 1 or the response gate.** Every screen showing evidence must show its role.

### 9.7 The four-part clock

Planned phase-day, elapsed calendar day, active-work day, and days blocked waiting. Surface as one
line with the rest behind a link. **A missed Day 14 reschedules downstream milestones and must never
silently advance a phase.** *(Not built in the prototype — held pending §9.10.)*

### 9.8 Phase 4's time budget, and Day 14's decision

If the intake time-budget answer is under 2h15, Phase 4 must offer four **recorded** options rather
than asserting the canonical routine: run as written, rotate the five jobs across the week, extend the
timeline (Day 14 moves and every milestone moves with it), or revise pace and scope. Store on its own
key — the prototype's first attempt shared `state.pace` with Phase 1's publish pace and the two
collided.

Day 14 ends in one recorded five-way decision: continue, revise positioning, revise magnet, collect
more evidence, stop. Each carries an explicit consequence, and **none of them retracts anything
automatically** — "if you want the posts down you take them down, and I record that you did."

### 9.9 Signals, Outreach, Content

**Signals** leads with four outcome families kept apart and never averaged: attention, conversation,
audience, business. Attention and conversation carry `MAY INFORM A ROUTING CHANGE`; audience and
business carry `NEVER USED TO SUPPRESS A PILLAR OR PLATFORM`. A quiet post that brought one lead is a
business win and must be said plainly. **Adopting an adjustment writes the change into the config the
skills read, applying from the next post on** — see v7 handoff §4: what exists today files a backlog
card instead, and the prototype's copy has to match whichever behaviour ships.

**Outreach** segments contacts into platforms, organizations by mission fit, and organizations with
open roles — the segment is what tells Muxin what angle to bring before she reads a word. Each row
carries who, why they are the contact, and when it was last pitched.

**Content** needs a third input: a **URL to something Muxin already published herself**. The prototype
has a paste field that treats the fetched post as already live, fans it out per platform, and never
reposts to the source. Backend: fetch and parse, mark `delivery_status: live_confirmed` with
`evidence.role = "historical_prior"` per §9.6, and hard-block any republish to the origin platform.

### 9.10 Open — the 14-day structure is approved to loosen

The rigid 14-day phase structure may become a test-and-read-responses loop. The redesign is
**undrafted** and changes tier-1 authority. §9.7 and parts of §9.1 are scaffolding for the rigid
version — build them last, or after the loosening is drafted.

### 9.11 Vault access

- **Pinned references** — the Starter Kit PDF, the session note, `rules.md`, `rules.yaml`. Read by
  path, content-hashed, version-locked per venture at kickoff so a Phase 3 decision stays traceable
  to the rules as they read then. The prototype shows these behind a collapsed
  "THE RULES IT RUNS UNDER".
- **Ad-hoc vault pull** — unrestricted read approved. `classifySource` already resolves a
  single-line path (an Obsidian note) into `.inbox`. For broader reads: **always show what was
  actually read**, since the vault also holds her job hunt, health and personal reviews.

### 9.12 The venture context rail

The Venture room's right rail shows **this venture's accumulated context**, not its source files.
Two groups: *your words* (name, what she is helping people do, who for, time available, the Day 14
scorecard, each stamped with its intake question number, rendered in her serif as a blockquote with
a link back to that answer in the thread) and *decided in the build* (platform, angles, magnet,
problem, product, price, the ask, daily pace, each stamped with the step that decided it and whether
it was the recommendation or her override). A third group appears only when she has overridden,
holding her reason. Empty before the interview: "Nothing gets drafted off an assumption."
