import { appendFileSync, existsSync, mkdirSync, readFileSync } from "node:fs";
import { artifactsPath, ventureDir } from "./paths.js";
import { artifactKindRule, type ArtifactKind, type VentureRules } from "./rules.js";

export type EditorialStatus = "draft" | "approved" | "discarded";
export type DeliveryStatus =
  | "not_applicable"
  | "awaiting_approval"
  | "ready"
  | "handed_off"
  | "live_confirmed"
  | "failed"
  | "cancelled";

export interface ClaimRef {
  claim: string;
  ref: string; // "intake:q11" or "confirmed_known:<id>"
}

export interface Evidence {
  type: "url" | "agent" | "attestation";
  value: string;
  provider?: string;
  confirmed_by?: "muxin" | "agent";
  confirmed_at?: string;
  // When the thing this evidence points at went public, if that differs from when it was
  // confirmed -- i.e. confirming a post Muxin had ALREADY published before this venture began
  // (v5 handoff §9.9). Absent means "it went live when it was confirmed", which is what every
  // delivery path in this repo does. This is the only input the evidence-role derivation needs
  // that the artifact does not already carry; the role itself is never stored, it is computed on
  // read by evidence-links.ts's deriveArtifactEvidenceRole (§9.6: never let a caller declare it).
  published_at?: string;
}

export interface Failure {
  // null for a manual artifact, where there is no provider and the message is what Muxin
  // reported -- docs/venture-schema-contract.md §4.1. Was `string` when deliver.ts, whose only
  // failure is a "substack-notes" one, was the sole writer.
  provider: string | null;
  message: string;
  retryable: boolean;
  at: string;
}

// docs/venture-schema-contract.md §4.2. Written ALONGSIDE, never over, the original `evidence`:
// an artifact carrying both was genuinely live and is now not, and both facts matter -- the first
// is why a checkpoint cleared, the second is why the thing is no longer out there. It carries its
// own attestation because the system can no more verify a takedown than it could verify the
// original posting.
export interface Retraction {
  attestation: string;
  retracted_at: string;
  retracted_by: "muxin";
}

export interface VentureArtifact {
  artifact_id: string;
  phase: number;
  artifact_kind: ArtifactKind;
  title: string;
  body_path: string | null;
  checkpoint_id: string | null;
  // Non-null only for structured artifact kinds (phase_1_research_plan): per-field-editable data
  // (confirmed_knowns[], open_unknowns[], probes[], reviewed_by_muxin, plan_version, ...). null
  // for the two post kinds, which use title/body_path/claim_refs instead.
  fields: Record<string, unknown> | null;

  delivery_mode: "manual" | "app" | "none";
  publishable: boolean;
  editorial_status: EditorialStatus;
  delivery_status: DeliveryStatus;
  evidence: Evidence | null;
  // Present iff this artifact was taken down after being live (§2.1). Its presence is what
  // separates "retracted" from a plain "discarded" on screen -- both are discarded x cancelled,
  // and §2.2 says the screen must not flatten them into one word.
  retraction: Retraction | null;
  failure: Failure | null;

  // §1B lineage fields
  origin_type: "venture";
  venture_id: string;
  venture_phase: number;
  message_id: string;
  cta_id: string | null;
  rules_version: string;

  // Phase 1 specific
  probe_id: string | null;
  unknown_id: string | null;
  claim_refs: ClaimRef[];

  // When Muxin edited the body herself, and null when she has not. It is the ONE fact that decides
  // whose words the room says the body is (docs/prototype-port-rules.md Rule 4: the AI register is
  // purple, and prose she wrote must never render in it). A timestamp rather than a flag because
  // the screen shows the day, and a day it can show is a day something recorded -- never derived
  // from updated_at, which every approve and every delivery also moves.
  //
  // Absent on every line written before this existed, so readLines() normalizes it to null: an old
  // artifact was not edited by her, which is a different fact from "unknown" only if something
  // could ever have set it, and nothing could.
  body_edited_by_muxin_at: string | null;

  created_at: string;
  updated_at: string;
  /** CLI that produced the judgment, when an agent run created this artifact. */
  engine?: string | null;
}

// §2.2's valid (editorial, delivery) combinations. Anything not listed here is rejected.
const VALID_COMBINATIONS = new Set<string>([
  "draft:not_applicable",
  "draft:awaiting_approval",
  "approved:ready",
  "approved:handed_off",
  "approved:live_confirmed",
  "approved:failed",
  "approved:not_applicable",
  "discarded:cancelled",
  "discarded:not_applicable",
  "discarded:live_confirmed", // retract path: discard after it already shipped keeps the record
]);

export function isValidCombination(editorial: EditorialStatus, delivery: DeliveryStatus): boolean {
  return VALID_COMBINATIONS.has(`${editorial}:${delivery}`);
}

function readLines(slug: string): VentureArtifact[] {
  const path = artifactsPath(slug);
  if (!existsSync(path)) return [];
  return readFileSync(path, "utf8")
    .split("\n")
    .filter((l) => l.trim())
    .map((l) => {
      const a = JSON.parse(l) as VentureArtifact;
      // Every line written before body_edited_by_muxin_at existed. null, never undefined, so a
      // consumer cannot accidentally treat "the key is missing" as a third state it is not.
      if (a.body_edited_by_muxin_at === undefined) a.body_edited_by_muxin_at = null;
      return a;
    });
}

// artifacts.jsonl is append-only: each write is a full snapshot line for that artifact_id.
// Reading folds to the latest line per id (last write wins), the same event-sourced spirit as
// canon.md and decisions.jsonl -- never an in-place rewrite of an existing line.
export function readArtifacts(slug: string): VentureArtifact[] {
  const lines = readLines(slug);
  const latest = new Map<string, VentureArtifact>();
  for (const a of lines) latest.set(a.artifact_id, a);
  return [...latest.values()];
}

export function readArtifact(slug: string, artifactId: string): VentureArtifact | undefined {
  return readArtifacts(slug).find((a) => a.artifact_id === artifactId);
}

function appendLine(slug: string, artifact: VentureArtifact): void {
  mkdirSync(ventureDir(slug), { recursive: true });
  appendFileSync(artifactsPath(slug), JSON.stringify(artifact) + "\n");
}

export interface CreateArtifactInput {
  artifact_id: string;
  phase: number;
  artifact_kind: ArtifactKind;
  title: string;
  body_path?: string | null;
  checkpoint_id?: string | null;
  fields?: Record<string, unknown> | null;
  venture_id: string;
  venture_phase: number;
  message_id: string;
  cta_id?: string | null;
  probe_id?: string | null;
  unknown_id?: string | null;
  claim_refs?: ClaimRef[];
  at: string;
  engine?: string | null;
}

// Stamps delivery_mode/publishable from rules.ts's kind table AT CREATE TIME and writes them
// onto the line -- the delivery path later reads the stored field, never re-derives it from
// artifact_kind. This is what keeps `publishable` explicit-not-inferred all the way through.
export function createArtifact(
  slug: string,
  rules: VentureRules,
  input: CreateArtifactInput
): VentureArtifact {
  const kindRule = artifactKindRule(rules, input.artifact_kind);
  const artifact: VentureArtifact = {
    artifact_id: input.artifact_id,
    phase: input.phase,
    artifact_kind: input.artifact_kind,
    title: input.title,
    body_path: input.body_path ?? null,
    checkpoint_id: input.checkpoint_id ?? null,
    fields: input.fields ?? null,
    delivery_mode: kindRule.delivery_mode,
    publishable: kindRule.publishable,
    editorial_status: "draft",
    delivery_status: kindRule.delivery_mode === "none" ? "not_applicable" : "awaiting_approval",
    evidence: null,
    retraction: null,
    failure: null,
    origin_type: "venture",
    venture_id: input.venture_id,
    venture_phase: input.venture_phase,
    message_id: input.message_id,
    cta_id: input.cta_id ?? null,
    rules_version: rules.rules_version,
    probe_id: input.probe_id ?? null,
    unknown_id: input.unknown_id ?? null,
    claim_refs: input.claim_refs ?? [],
    body_edited_by_muxin_at: null,
    created_at: input.at,
    updated_at: input.at,
    engine: input.engine ?? process.env.CONTENT_AGENT_ENGINE ?? null,
  };
  appendLine(slug, artifact);
  return artifact;
}

export class InvalidTransitionError extends Error {
  constructor(from: VentureArtifact, editorial: EditorialStatus, delivery: DeliveryStatus) {
    super(
      `invalid venture artifact transition for ${from.artifact_id}: ` +
        `${from.editorial_status}:${from.delivery_status} -> ${editorial}:${delivery}`
    );
    this.name = "InvalidTransitionError";
  }
}

export interface TransitionPatch {
  editorial_status?: EditorialStatus;
  delivery_status?: DeliveryStatus;
  evidence?: Evidence | null;
  // Deliberately NOT paired with an `evidence` clear: §2.1 is explicit that a retract writes this
  // "without touching `evidence`", because erasing that record would falsify the history a
  // cleared checkpoint rests on. Set by retractArtifact() in artifact-lifecycle.ts, which is the
  // only caller that should ever pass it.
  retraction?: Retraction | null;
  failure?: Failure | null;
  // Set by editArtifactBody() in artifact-lifecycle.ts, which is the only caller that should ever
  // pass it -- it is the record of Muxin having rewritten the body herself, and nothing else may
  // claim that on her behalf.
  body_edited_by_muxin_at?: string;
}

export function transitionArtifact(
  slug: string,
  artifactId: string,
  patch: TransitionPatch,
  at: string
): VentureArtifact {
  const current = readArtifact(slug, artifactId);
  if (!current) throw new Error(`no such artifact: ${artifactId}`);
  const next: VentureArtifact = {
    ...current,
    ...patch,
    updated_at: at,
  };
  if (!isValidCombination(next.editorial_status, next.delivery_status)) {
    throw new InvalidTransitionError(current, next.editorial_status, next.delivery_status);
  }
  appendLine(slug, next);
  return next;
}

// Patches keys inside a structured artifact's `fields` bag (e.g. reviewed_by_muxin,
// confirmed_by_muxin on a confirmed_knowns entry). Separate from transitionArtifact -- fields
// edits aren't part of the editorial/delivery state machine and need no combination check.
export function updateArtifactFields(
  slug: string,
  artifactId: string,
  patch: Record<string, unknown>,
  at: string
): VentureArtifact {
  const current = readArtifact(slug, artifactId);
  if (!current) throw new Error(`no such artifact: ${artifactId}`);
  const next: VentureArtifact = {
    ...current,
    fields: { ...(current.fields ?? {}), ...patch },
    updated_at: at,
  };
  appendLine(slug, next);
  return next;
}

// Reaches into a `phase_1_research_read` artifact's `fields.findings[]` to set ONE finding's
// `muxin_confirmed_emergent` by id -- updateArtifactFields only merges shallowly at the top
// level of `fields`, which can't touch a single array entry. This is the ONLY place in the
// codebase that may set `muxin_confirmed_emergent` to true/false (see self-stamp.test.ts).
export function updateResearchReadFinding(
  slug: string,
  artifactId: string,
  findingId: string,
  confirmed: boolean,
  at: string
): VentureArtifact {
  const current = readArtifact(slug, artifactId);
  if (!current) throw new Error(`no such artifact: ${artifactId}`);
  const findings = (current.fields?.findings as { finding_id: string; finding_origin: string }[] | undefined) ?? [];
  const idx = findings.findIndex((f) => f.finding_id === findingId);
  if (idx === -1) throw new Error(`no such finding "${findingId}" on artifact ${artifactId}`);
  if (findings[idx].finding_origin !== "emergent") {
    throw new Error(
      `finding "${findingId}" is not emergent -- muxin_confirmed_emergent only applies to emergent findings`
    );
  }
  const nextFindings = findings.map((f, i) => (i === idx ? { ...f, muxin_confirmed_emergent: confirmed } : f));
  const next: VentureArtifact = {
    ...current,
    fields: { ...(current.fields ?? {}), findings: nextFindings },
    updated_at: at,
  };
  appendLine(slug, next);
  return next;
}

// The publish gate. `manual`-kind artifacts (substack-post) are never `publishable: true` by
// design -- publishable means "the app can deliver this itself", which is exactly what a manual
// hand-off isn't. So the gate branches on delivery_mode:
//   app    -> ALL of publishable, approved, ready (each alone is insufficient)
//   manual -> approved AND ready (publishable is correctly always false here)
//   none   -> never deliverable
export function readyForDelivery(a: VentureArtifact): boolean {
  if (a.editorial_status !== "approved" || a.delivery_status !== "ready") return false;
  if (a.delivery_mode === "app") return a.publishable === true;
  if (a.delivery_mode === "manual") return true;
  return false;
}
