// Job queue + Claude subprocess runner for the review GUI (serve.ts). Every Claude-spawning GUI
// action funnels through the ONE queue defined here (Codebase review Phase 2, "GUI actions"):
// the "Add / Queue" atomize/video jobs, "Revise with Claude" (reviseDerivative/reviseBrief),
// "Duplicate to platform" (duplicateToPlatform), and — via runQueued/runClaudeSpawn, imported back
// into serve.ts — the Strategy tab's generateInsights/askInsights. One `draining` mutex serializes
// ALL of them, so GUI concurrency is bounded and every run gets a persisted log + heartbeat exactly
// like an atomize job (previously only atomize jobs queued; the other four spawned unbounded).
// Split out of serve.ts (Codebase review Phase 5c).

import { readFileSync, writeFileSync, readdirSync, existsSync, mkdirSync, createWriteStream, rmSync } from "node:fs";
import { join, basename } from "node:path";
import { homedir, tmpdir } from "node:os";
import { randomUUID } from "node:crypto";
import { spawn, execFileSync, type ChildProcess } from "node:child_process";
import { repoRoot } from "../db/db.js";
import { appendRow, readQueue, stampOrigin } from "../publish/queue.js";
import { TEXT_PLATFORMS } from "../publish/typefully.js";
import { resolveAngle } from "../atomize/spin.js";
import { loadPlatforms } from "../config/platforms.js";
import { splitFrontmatter } from "../util/frontmatter.js";
import { upsertFrontmatterField } from "../outreach/qualify.js";
import { CONTENT, safeFolder, isValidLens } from "./rows.js";
import { roundCount } from "./develop.js";
import { briefRevisePrompt, latestBriefPath } from "./serve.js";
import { runDraft, draftModel, type DraftResult } from "../outreach/draft.js";
import { CHARLES_DIR, listCharlesPosts, readCharlesPost, stampCharlesEngine, type CharlesPost } from "./charles.js";
import { saveSceneBeats } from "./fiction.js";
import { logCost } from "../util/cost-log.js";
import { resolveSeriesDir, chapterNumbers, readChapter } from "../fiction/_series.js";
import { continuityReportPath, readContinuityReport } from "../fiction/continuity.js";
import { buildEngineSpawn, enginePrompt, ENGINE_COMMANDS, ENGINE_LABELS, type Engine, type EngineSpawnOptions } from "./engines.js";

// Per-job stdout/stderr logs for the atomize job queue (see the Job interface below) — persisted
// to disk so a job's real output survives past the 40MB in-memory buffer execFile used to impose,
// and so a "view log" link + failure log-tail have something to read.
const JOB_LOG_DIR = join(homedir(), ".content-agents", "logs", "gui-jobs");
export function jobLogPath(jobId: string): string {
  return join(JOB_LOG_DIR, `${jobId}.log`);
}

function stampFileEngine(path: string, engine: Engine): void {
  if (!existsSync(path)) return;
  const raw = readFileSync(path, "utf8");
  const { header, body } = splitFrontmatter(raw);
  if (!header) return;
  const nextHeader = upsertFrontmatterField(header, "engine", engine);
  if (nextHeader !== header) writeFileSync(path, `${nextHeader}${body.trim() ? `${body.trim()}\n` : ""}`);
}

function stampFolderEngine(folder: string, engine: Engine): void {
  for (const row of readQueue(folder).rows) {
    if (row.asset) stampFileEngine(join(folder, row.asset), engine);
  }
}

// The last non-empty line of accumulated output — the "heartbeat" shown in the jobs pill so a
// long-running job doesn't read as a silent black box. Pure/testable: takes the buffer directly
// rather than reading a file.
export function lastNonEmptyLine(text: string): string | null {
  const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
  return lines.length ? lines[lines.length - 1] : null;
}

// Last `n` lines of `text`, joined back with newlines — used to attach a bounded log tail to
// job.error on failure instead of the whole (potentially large) log.
export function tailLines(text: string, n: number): string {
  const lines = text.split("\n").filter((l) => l.trim().length > 0);
  return lines.slice(-n).join("\n");
}

// "Revise with Claude" ("Ask Claude" in the GUI): shell out to headless Claude Code (`claude -p`),
// which uses Muxin's subscription ($0 marginal), to edit ONE derivative in place per a
// natural-language instruction.
const REVISE_TIMEOUT_MS = 180_000;
function engineName(job: Pick<Job, "engine">): string {
  return ENGINE_LABELS[job.engine ?? "claude"];
}

// Ask Claude's real scope, in one line, reused everywhere the boundary needs stating: editing ONE
// existing derivative's body text in place. Anything else (retargeting the platform, creating a
// new post) is out of scope BY DESIGN — "Duplicate to platform" is the actual affordance for that
// (card 9304e4a5).
const REVISE_SCOPE = "edit this ONE post's body text in place";

// The exact line Claude must print (and ONLY that, no edit) when a request falls outside
// REVISE_SCOPE — e.g. "make this an X post instead" (a platform/frontmatter change) or "write a
// new post about..." (a new derivative). Matched back by parseReviseRefusal. Previously an
// out-of-scope ask just silently changed nothing and surfaced as a generic "didn't change
// anything" — indistinguishable from Claude simply not bothering. Now it's a real, specific reason.
const REFUSAL_MARKER = "REFUSED:";

// Build the instruction for a single-file, extraction-first revision. Kept explicit + exported so
// the guardrails (edit only this file, keep frontmatter, stay traceable, voice.yaml) can't drift.
export function revisePrompt(slug: string, id: string, platform: string, instruction: string): string {
  const isCardCaption = /^quote-card-\d+-[a-z]+$/i.test(id);
  return [
    `Revise ONE content derivative in place for Muxin Li's content pipeline. Do not run shell commands; just edit the one file, then stop.`,
    ``,
    `File to edit: content/${slug}/derivatives/${id}.md   (platform: ${platform || "?"})`,
    `Muxin's request: "${instruction}"`,
    ``,
    `Your scope is ONLY to ${REVISE_SCOPE}. If the request asks for anything outside that scope —`,
    `changing which platform this derivative targets (its frontmatter \`platform\`), creating a`,
    `brand-new post/derivative, or anything that isn't an edit to this one file's existing body —`,
    `do NOT edit the file. Instead print EXACTLY one line to stdout: "${REFUSAL_MARKER} <short reason,`,
    `one sentence>" (e.g. "${REFUSAL_MARKER} that would retarget the platform — use Duplicate to`,
    `platform instead"), then stop. Do not print anything else in that case.`,
    ``,
    `Rules (when the request IS in scope):`,
    `- Edit ONLY that one file. Touch nothing else.`,
    `- Keep the YAML frontmatter block intact (platform, spin, angle, source_lines, cta, ...). Change only the body (the post text) unless the request is explicitly about frontmatter.`,
    `- Extraction-first: the body must stay traceable to Muxin's source at content/${slug}/source.md. If the derivative has spin: true you may re-angle within its config/platforms.yaml spin_angles guardrails, but NEVER invent a claim, statistic, metaphor, or worldview Muxin did not express.`,
    `- Follow config/voice.yaml: no em dashes, no AI tells, Muxin's plain PM voice.`,
    `- Respect the platform's max_chars in config/platforms.yaml.`,
    isCardCaption
      ? `- This is a quote-card CAPTION: it gives CONTEXT around the quote shown on the image. Do not restate the quote; keep it context-only.`
      : ``,
    `- Be surgical: apply the request, do not rewrite what was not asked.`,
  ]
    .filter(Boolean)
    .join("\n");
}

// Pure: pulls Claude's refusal reason (if any) out of a job's captured stdout. Exported so the
// refusal path is unit-testable without spawning a subprocess.
export function parseReviseRefusal(stdout: string): string | null {
  const m = stdout.match(new RegExp(`^${REFUSAL_MARKER}\\s*(.+)$`, "m"));
  return m ? m[1].trim() : null;
}

// ── Stdout markers: ordered steps, and a job that stops and asks ─────────────────────────────────
// Same marker-on-stdout pattern parseReviseRefusal already established, extended to two more
// protocols a skill can opt into. Both are OPTIONAL: a skill that emits neither keeps behaving
// exactly as it does today (steps stays empty, stepTotal null, and the UI falls back to the
// lastStdoutLine heartbeat). Nothing in the repo emits these yet — the parsers ship with their
// tests as the only consumer, and skills get instrumented separately.
//
//   STEP <n>/<total> <label>     one line, before the step's work begins, n 1-indexed
//   ASK <question>?              one sentence, ending in a question mark
//   ASK-OPTION <label>           2 or 3 of them; the subprocess prints them and EXITS 0
//
// A skill never waits on an answer: it prints the ask and stops, so a human's think time can't
// occupy the one job lane or burn the spawn timeout.

// Pure: reads one line as a step marker, or null if it isn't one. Exported for direct unit tests.
export function parseStepMarker(line: string): { n: number; total: number; label: string } | null {
  const m = /^STEP\s+(\d+)\/(\d+)\s+(\S.*)$/.exec(line.trim());
  if (!m) return null;
  const n = Number(m[1]);
  const total = Number(m[2]);
  // A 0th step, or one past the declared total, is a malformed marker rather than a step.
  if (n < 1 || total < 1 || n > total) return null;
  return { n, total, label: m[3].trim() };
}

// Pure: reads one line as the question half of an ask, or null.
export function parseAskMarker(line: string): string | null {
  const m = /^ASK\s+(\S.*\?)$/.exec(line.trim());
  return m ? m[1].trim() : null;
}

// Pure: reads one line as one ask option, or null.
export function parseAskOptionMarker(line: string): string | null {
  const m = /^ASK-OPTION\s+(\S.*)$/.exec(line.trim());
  return m ? m[1].trim() : null;
}

// The mutable slice of a Job the marker protocols write to — narrowed so the ingest below is
// testable against a plain object, no spawn and no full Job needed.
export type MarkerTarget = Pick<Job, "steps" | "stepTotal" | "step" | "ask">;

// Apply every marker in a chunk of already-line-complete stdout. A chunk carrying several STEP
// markers advances to the LAST one (a fast skill can emit two before we ever see the output), and
// ASK-OPTION lines accumulate onto the ask the preceding ASK line opened.
export function ingestMarkerChunk(target: MarkerTarget, text: string, now: number = Date.now()): void {
  for (const line of text.split("\n")) {
    const step = parseStepMarker(line);
    if (step) {
      target.stepTotal = step.total;
      // `step` counts COMPLETED steps: marker n means 1..n-1 finished and n is in flight.
      target.step = step.n - 1;
      while (target.steps.length < step.n - 1) target.steps.push("");
      target.steps[step.n - 1] = step.label;
      continue;
    }
    const question = parseAskMarker(line);
    if (question) {
      target.ask = { question, options: [], askedAt: now };
      continue;
    }
    const option = parseAskOptionMarker(line);
    if (option && target.ask) target.ask.options.push(option);
  }
}

// Whether a failed spawn is worth another attempt. Sibling to decodeSpawnFailure rather than a
// change to it: serve.test.ts imports that function's `string | null` shape, and the UI needs a
// separate boolean to decide whether to offer Retry at all.
//
// Everything except a missing binary is retryable. A timeout may clear on a quieter machine, a
// non-zero exit is usually transient, and a clean exit that reached the failure path means the
// artifact check caught a run that finished without writing anything — worth one more attempt.
// ENOENT is the one no: retrying cannot put `claude` back on the PATH.
export function isRetryableFailure(result: { code: number | null; timedOut: boolean; enoent: boolean }): boolean {
  return !result.enoent;
}

// A job goes `blocked` only when the subprocess asked a real, answerable question AND the spawn
// itself was clean. Two guards, both load-bearing:
// - A spawn failure (non-zero exit, timeout, missing binary) beats a stray ASK line: the run broke,
//   and a question it printed on the way down is not a decision point Muxin should be handed.
// - An ask needs at least 2 options. The answer route validates against the recorded options and
//   clearFinishedJobs never sweeps `blocked`, so a 0-or-1-option ask would strand a job that can
//   neither be answered nor cleared. A malformed ask falls through to the normal done/failed path.
export function shouldBlockOnAsk(
  ask: { question: string; options: string[] } | null,
  spawn: { code: number | null; timedOut: boolean; enoent: boolean } | null,
): boolean {
  if (!ask || ask.options.length < 2) return false;
  if (!spawn) return false;
  return !spawn.enoent && !spawn.timedOut && spawn.code === 0;
}

// The answer Muxin picked, handed to the fresh spawn of the requeued job. A dead subprocess cannot
// be resumed, so the answer rides into the next run's prompt instead (v5 handoff §8.1) — the job
// re-runs its early steps, which is the accepted tradeoff.
export function answerPromptSuffix(answer: string): string {
  return `\n\nYou asked Muxin a question on a previous run and stopped. Her answer: "${answer}". Take that as decided, do not ask it again, and carry on.`;
}

// Run the revision through headless Claude Code (subscription, no per-token API cost), then return
// the edited body. Failures (missing CLI, timeout, non-zero exit, refusal, no-op) surface as
// thrown messages the GUI shows durably on the row instead of a silent no-op or a crash. Routed
// through runQueued so "Ask Claude" shares the ONE job queue/log/heartbeat every other Claude spawn
// in this GUI does (Codebase review Phase 2) — no separate concurrency lane.
export async function reviseDerivative(slug: string, id: string, instruction: string, engine: Engine = "claude"): Promise<string> {
  const folder = safeFolder(slug);
  if (!/^[\w.-]+$/.test(id)) throw new Error("bad id");
  if (!instruction.trim()) throw new Error("tell Claude what to change first");
  const p = join(folder, "derivatives", `${id}.md`);
  if (!existsSync(p)) throw new Error("no such derivative to revise");

  const original = splitFrontmatter(readFileSync(p, "utf8"));
  const platform = typeof original.fm.platform === "string" ? original.fm.platform : "";
  const prompt = revisePrompt(slug, id, platform, instruction.trim());

  return runQueued("revise", `Revise ${slug}/${id}`, async (job) => {
    const result = await runClaudeSpawn(job, prompt, { timeoutMs: REVISE_TIMEOUT_MS });
    const failure = decodeSpawnFailure(result, job.id, {
      timeoutVerb: "Claude", timeoutLabel: `${REVISE_TIMEOUT_MS / 1000}s`, exitVerb: "Claude revise",
    });
    if (failure) throw new Error(failure.replace(/Claude/g, engineName(job)));

    const refusal = parseReviseRefusal(result.stdout);
    if (refusal) throw new Error(`The selected engine can't do that: ${refusal}`);

    const after = splitFrontmatter(readFileSync(p, "utf8")).body;
    if (after === original.body) {
      throw new Error(`${engineName(job)} ran but didn't change anything — try a more specific instruction`);
    }
    stampFileEngine(p, engine);
    return after;
  }, engine);
}

// Same "revise with Claude" pattern as reviseDerivative, but for the latest strategy brief instead
// of a derivative — briefRevisePrompt/latestBriefPath stay in serve.ts (part of the Strategy/
// Analytics block), imported back here since this is the one place that spawns the subprocess.
export async function reviseBrief(instruction: string, engine: Engine = "claude"): Promise<{ path: string; content: string }> {
  const abs = latestBriefPath();
  if (!abs) throw new Error("no strategy brief exists yet — run /strategy first");
  if (!instruction.trim()) throw new Error("tell Claude what to change first");
  const relPath = abs.slice(repoRoot.length + 1);
  const before = readFileSync(abs, "utf8");
  const prompt = briefRevisePrompt(relPath, instruction.trim());

  return runQueued("brief-revise", `Revise brief: ${relPath}`, async (job) => {
    const result = await runClaudeSpawn(job, prompt, { timeoutMs: REVISE_TIMEOUT_MS });
    const failure = decodeSpawnFailure(result, job.id, {
      timeoutVerb: "Claude", timeoutLabel: `${REVISE_TIMEOUT_MS / 1000}s`, exitVerb: "Claude revise",
    });
    if (failure) throw new Error(failure);
    const after = readFileSync(abs, "utf8");
    if (after === before) throw new Error(`${engineName(job)} ran but didn't change anything — try a more specific instruction`);
    return { path: relPath, content: after };
  }, engine);
}

// Same "revise ONE file with Claude" pattern as briefRevisePrompt/reviseBrief, scoped to a drafted
// (never locked) outreach message. Exported so the guardrails (one file, frontmatter intact,
// evidence-grounded, voice.yaml) are unit-testable — this prompt decides what an outreach message
// can say, so it's content-generation-adjacent (CLAUDE.md rule 7 flags it at the PR).
export function outreachMessageRevisePrompt(relPath: string, channel: string, instruction: string): string {
  return [
    `Revise ONE file in place for Muxin Li's outreach pipeline: a drafted outreach message (channel: ${channel || "?"}). Do not run shell commands; just edit the one file, then stop.`,
    ``,
    `File to edit: ${relPath}`,
    `Muxin's request: "${instruction}"`,
    ``,
    `Rules:`,
    `- Edit ONLY that one file. Touch nothing else — no lead.md, no other message, no review-queue.md.`,
    `- Keep the YAML frontmatter block intact (lead, channel, evidence, classification, status). Change only the body (the message text).`,
    `- Stay grounded in the lead's cited evidence (the lead.md ## Evidence items the frontmatter references) — NEVER invent a fact about the company, the person, or Muxin.`,
    `- Follow config/voice.yaml: no em dashes, no AI tells, Muxin's plain PM voice.`,
    `- Be surgical: apply the request, do not rewrite what was not asked.`,
  ].join("\n");
}

// Revise a lead's drafted outreach message in place (Outreach tab's "Revise with AI"). Refuses a
// locked message — a locked text is Muxin's final word; a new angle goes through the existing
// draft-follow-up path instead. `dir`/`file` are validated by the route (isValidLeadDir + the
// messages/message-NN.md shape) before this runs.
export async function reviseOutreachMessage(dir: string, file: string, instruction: string, engine: Engine = "claude"): Promise<{ body: string }> {
  if (!instruction.trim()) throw new Error("tell Claude what to change first");
  const abs = join(repoRoot, dir, file);
  if (!existsSync(abs)) throw new Error("no such message to revise");
  const before = splitFrontmatter(readFileSync(abs, "utf8"));
  if (String(before.fm.status ?? "").trim() === "locked") {
    throw new Error("this message is locked — use Draft follow-up for a new touch instead");
  }
  const channel = typeof before.fm.channel === "string" ? before.fm.channel : "";
  const prompt = outreachMessageRevisePrompt(`${dir}/${file}`, channel, instruction.trim());

  // Its own kind, not the shared "revise": a job's kind is what picks the room its progress shows
  // in, and "revise" routes to Content. Clicking "Update it" on an Outreach thread used to leave
  // the Outreach strip idle and post the Connector's work under Content as the Formatter. Content
  // derivative revises still use "revise" and still belong in Content.
  return runQueued("outreach-revise", `Revise outreach message: ${dir}/${file}`, async (job) => {
    const result = await runClaudeSpawn(job, prompt, { timeoutMs: REVISE_TIMEOUT_MS });
    const failure = decodeSpawnFailure(result, job.id, {
      timeoutVerb: "Claude", timeoutLabel: `${REVISE_TIMEOUT_MS / 1000}s`, exitVerb: "Claude revise",
    });
    if (failure) throw new Error(failure);
    const after = splitFrontmatter(readFileSync(abs, "utf8")).body;
    if (after === before.body) {
      throw new Error(`${engineName(job)} ran but didn't change anything — try a more specific instruction`);
    }
    return { body: after.trim() };
  }, engine);
}

// ── Content ingestion: the GUI's front door ─────────────────────────────────────────────────
// The review page is an inbox; this is the door. Muxin drops a source — pasted text, a file path
// (e.g. an Obsidian note), a Substack URL, or "pull my Notes" — and the GUI runs the REAL /atomize
// headlessly via `claude -p` on his subscription ($0 marginal), one job at a time so he can keep
// queueing while it works. Nothing here publishes: atomize only drafts + queues, and every
// derivative still lands `pending` for review on the other tab (CLAUDE.md rule 2).
const INBOX = join(CONTENT, ".inbox"); // pasted/copied sources live here (git-ignored)
const ATOMIZE_TIMEOUT_MS = 15 * 60_000;
// acceptEdits (not bypass) is enough: the project settings already allowlist `npm run:*`, which is
// all atomize shells out to. Overridable for a setup that needs a different mode.
const ATOMIZE_PERMISSION_MODE = process.env.ATOMIZE_PERMISSION_MODE ?? "acceptEdits";

// "blocked" is a job that printed an ASK and stopped: it is waiting on Muxin, not on the machine.
// It does NOT hold the job lane (see settleJob below) and it is never swept by clearFinishedJobs —
// an unanswered question is not finished work.
//
// "stopped" is Muxin pressing Stop it. It is deliberately its OWN status rather than a reuse of
// either neighbour:
// - Not `blocked`: blocked means "the subprocess asked an answerable question and is waiting".
//   answerJob validates her answer against `ask.options`, and a stopped job has no ask — so it
//   would be unanswerable AND, since jobIsSweepable only sweeps `blocked` once `answer !== null`,
//   permanently unclearable. That is exactly the stranding the >=2-options guard in
//   shouldBlockOnAsk exists to prevent.
// - Not `failed`: her stopping something is not a break. `failed` carries retry-as-repair
//   semantics ("the run broke, the same attempt may work") she never asked for.
// Like `done`/`failed` it is finished work, so clearFinishedJobs sweeps it; unlike them it is
// never retryable (see settleJob).
type JobStatus = "queued" | "running" | "blocked" | "done" | "failed" | "stopped";
// "url" | "file" | "text" | "notes" | "continue" | "video" are the atomize-family kinds (dispatch
// a slash-command against a folder/source, verified by artifact check — see drain() below).
// "revise" | "brief-revise" | "insights" | "ask-insights" | "venture-analysis" | "duplicate" | "draft-follow-up" |
// "outreach-revise" | "pull" | "strategy" | "scout" are generic task jobs (run an arbitrary async task via runQueued)
// — the four call sites complaint 2 flagged as spawning unbounded, plus "Duplicate to platform",
// the Follow-ups tab's "Draft follow-up", the Analytics tab's "Pull fresh now" (runCommandSpawn,
// not a claude spawn) and "Refresh brief" (a full /strategy run), and the Outreach tab's "Scout
// new leads" (npm run scout). All families share the same queue/mutex/log/heartbeat.
// "develop" | "develop-reply" are the Develop tab's advisor rounds — same slash-command-dispatch
// shape as the atomize family (`/develop <arg>`), verified by their own artifact check (a new
// parseable round in develop/advice.json — see runDevelopJob below).
export type JobKind =
  | "url" | "file" | "text" | "notes" | "continue" | "video"
  | "develop" | "develop-reply"
  | "revise" | "brief-revise" | "insights" | "ask-insights" | "venture-analysis" | "venture-step" | "duplicate" | "draft-follow-up"
  | "outreach-revise"
  | "pull" | "strategy" | "scout" | "charles-draft"
  | "fiction-draft" | "fiction-continuity";

// Kinds whose stdout IS the deliverable, not a progress channel. `runDraft` takes the spawn's
// stdout as the outreach message body, and `ask-insights` returns it as the answer Muxin reads.
// Marker parsing is skipped for these entirely, STEP and ASK alike: a drafted message carrying a
// line that reads like `ASK ...?` plus two `ASK-OPTION` lines would otherwise flip a finished job
// to blocked and, once answered, append a duplicate message file. `draft-follow-up` already
// documents the STEP half of this rule in prose; this makes both halves real.
// Note which kinds are NOT here: `charles-draft` and `revise` both verify by artifact (a new
// review-queue row, an edited file), so their stdout is free to carry markers.
export const MARKER_EXEMPT_KINDS: ReadonlySet<JobKind> = new Set<JobKind>(["draft-follow-up", "ask-insights"]);

interface Job {
  id: string;
  kind: JobKind;
  label: string;
  engine?: Engine; // selected CLI for this run; old callers default to Claude
  arg: string; // atomize-family only: what the slash command receives (url, .inbox path, folder, "notes")
  status: JobStatus;
  slugs: string[]; // content folders touched — linked back so the Review tab can jump to them
  error: string | null;
  createdAt: number;
  startedAt: number | null;
  finishedAt: number | null;
  lastStdoutLine: string | null; // heartbeat — last non-empty line seen so far, updated as output streams in
  // Ordered steps, from the STEP markers a skill opts into emitting. Empty/null for every skill
  // that emits none, which is all of them today — the UI falls back to lastStdoutLine there.
  steps: string[]; // labels in order, growing toward stepTotal
  stepTotal: number | null;
  step: number; // COMPLETED steps — 0 before the first marker, stepTotal on a clean finish
  failedAtStep: number | null; // which step died, or null when the job ran without steps
  retryable: boolean; // whether Retry is worth offering — see isRetryableFailure
  ask: { question: string; options: string[]; askedAt: number } | null;
  answer: string | null; // what Muxin picked, on the requeued job that carries it forward
  // Task jobs only (revise/brief-revise/insights/ask-insights/duplicate) — the actual work this job
  // runs once it's its turn. Never serialized: publicJob() below is an explicit allowlist that omits
  // it, so this stays an internal queue-execution detail, not part of the polled /api/jobs shape.
  task?: (job: Job) => Promise<void>;
  // Last runCommandSpawn result on this job, kept so the ONE settle point can classify a failure
  // (retryable?) and tell a deliberate ask apart from a broken run, without threading the result
  // back out of five different run functions. Internal, omitted from publicJob like `task`.
  lastSpawn?: { code: number | null; timedOut: boolean; enoent: boolean };
  // Fiction jobs only: the free text a fiction run needs (her beats, or her second-pass note) plus
  // which chapter it targets. Kept OFF `arg` on purpose — `arg` is a shell-ish token every other
  // kind treats as one word, and a paragraph of beats does not belong there. Internal, and omitted
  // from publicJob() like `task` and `lastSpawn`.
  payload?: { mode?: "draft" | "repass"; beats?: string; note?: string; series?: string; chapter?: number; engine?: Engine };
  // Subprocess jobs only: the live child, kept ONLY so stopJob has something to signal. Set in
  // runCommandSpawn, cleared on close. Internal and omitted from publicJob like `task` — a
  // ChildProcess is not JSON-serializable, so leaking it would break the /api/jobs read outright.
  proc?: ChildProcess;
  // Set by stopJob BEFORE it signals anything. settleJob checks it FIRST, ahead of every other
  // verdict, because a SIGTERM'd `claude` exits 143 rather than dying by signal (see
  // isSpawnTimeout) — so the close handler hands back a failure-shaped result for a run Muxin
  // deliberately ended. Without this flag every Stop would render as "Did not work".
  stoppedByMuxin?: boolean;
  // Task jobs only (runQueued): reject the caller-facing promise this job's closure would
  // otherwise settle. A stopped queued job never runs its task, so without this the HTTP request
  // that awaited runQueued() would hang forever. Internal, omitted from publicJob.
  discard?: (reason: Error) => void;
}

// The fields every enqueue site initializes identically. Kept in one place so a new job kind can't
// quietly ship without steps/ask bookkeeping.
function freshJobFields(): Pick<Job, "status" | "slugs" | "error" | "createdAt" | "startedAt" | "finishedAt" | "lastStdoutLine" | "steps" | "stepTotal" | "step" | "failedAtStep" | "retryable" | "ask" | "answer"> {
  return {
    status: "queued", slugs: [], error: null,
    createdAt: Date.now(), startedAt: null, finishedAt: null, lastStdoutLine: null,
    steps: [], stepTotal: null, step: 0, failedAtStep: null, retryable: false, ask: null, answer: null,
  };
}
export const jobs: Job[] = [];
let jobSeq = 0;
let draining = false;

// "Clear queue" (GUI) only ever removes finished entries — queued/running jobs stay untouched, and
// so does an UNANSWERED `blocked` job: it is waiting on Muxin, not finished work, and clearing it
// would throw away the question. An ANSWERED blocked job is a different thing: answerJob already
// requeued a fresh job carrying her answer, so the original is a settled record and sweepable like
// any other. Without that, an answered ask stuck in the list forever with no way to dismiss it.
// drain() finds work via jobs.find(status==="queued"), not by index, so splicing mid-array here is
// safe even while a job is actively running.
export function jobIsSweepable(job: Pick<Job, "status" | "answer">): boolean {
  // `stopped` sweeps like done/failed: it is finished work by Muxin's own decision, and leaving it
  // out would make "Clear finished" quietly incomplete.
  if (job.status === "done" || job.status === "failed" || job.status === "stopped") return true;
  return job.status === "blocked" && job.answer !== null;
}
export function clearFinishedJobs(): number {
  let removed = 0;
  for (let i = jobs.length - 1; i >= 0; i--) {
    if (jobIsSweepable(jobs[i])) {
      jobs.splice(i, 1);
      removed++;
    }
  }
  return removed;
}

// Job ids must stay unique across a server RESTART, not just within one process: they key the
// persisted per-job log file (jobLogPath) under ~/.content-agents/logs/gui-jobs/, which outlives
// the process. `jobSeq` alone resets to 0 on every restart, so a bare `job-${++jobSeq}` reissues
// "job-1", "job-2", ... every time the GUI restarts — colliding with a prior run's ids and, since
// runClaudeSpawn opens that log file in append mode, silently concatenating this run's output onto
// whatever an unrelated old run already wrote there (surfaced as mixed-in stale content in the
// queue UI's error/log view). Prefixing with the process start time makes a collision require two
// server starts landing in the same millisecond — effectively impossible.
//
// buildJobId is the pure piece of that invariant (session start ms + intra-session sequence
// number), split out so the uniqueness guarantee is directly unit-testable without needing to
// simulate an actual process restart (jobIdPrefix/jobSeq below are the real module-level wiring).
export function buildJobId(sessionStartMs: number, seq: number): string {
  return `job-${sessionStartMs}-${seq}`;
}
const jobIdPrefix = Date.now();
function nextJobId(): string {
  return buildJobId(jobIdPrefix, ++jobSeq);
}

// Enqueue an arbitrary async task through the SAME queue/mutex atomize jobs use, so it's bounded
// by the one `draining` gate and shows up in the jobs pill with a real log + heartbeat (via
// runClaudeSpawn inside the task). The caller's promise resolves/rejects with whatever `task`
// returns/throws — the job bookkeeping (status/error/finishedAt) is separate, driven by drain().
export function runQueued<T>(kind: JobKind, label: string, task: (job: Job) => Promise<T>, engine: Engine = "claude"): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const id = nextJobId();
    const job: Job = {
      id, kind, label, arg: "", engine, ...freshJobFields(),
      // Writes to `j`, the job actually running, NOT the captured `job`: an answered job is
      // requeued as a CLONE that reuses this same closure, and a rerun failure must land its error
      // on the clone, not back on the original blocked job.
      // Muxin's Stop it, on a task job that never gets to run its closure. Without this the HTTP
      // request that awaited runQueued() would hang forever waiting on a promise nothing settles.
      // Rejecting early IS "discard the result": if the task was already mid-flight and later
      // resolves, that resolve lands on an already-settled promise and is a harmless no-op.
      // Rejects the promise WITHOUT writing job.error: a stop is not a fault, and settleJob's
      // rule 0 keeps a stopped job's error null.
      discard: (reason: Error) => reject(reason),
      task: async (j) => {
        try {
          resolve(await task(j));
        } catch (e) {
          j.error = e instanceof Error ? e.message : String(e);
          reject(e);
          throw e; // rethrow so drain()'s own try/catch also marks the job "failed", not "done"
        }
      },
    };
    jobs.push(job);
    void drain();
  });
}

// Generic spawn: streamed to the job's persisted log + heartbeat exactly like the atomize path
// (persist + stream, not execFile's 40MB in-memory buffer). Shared by every subprocess-spawning
// call site in the GUI — atomize-family jobs AND task jobs (revise/brief-revise/insights/
// ask-insights/duplicate/pull) — so they all get the same log file + heartbeat UX. `stdout` is
// captured separately (not just written to the log) for callers that need the process's actual
// answer text (insights/ask) or a refusal marker (revise), since the log interleaves stdout+stderr.
export interface CommandSpawnResult {
  code: number | null;
  timedOut: boolean;
  enoent: boolean;
  stdout: string;
}
// Node's own `timeout` option kills a stuck child with `killSignal` (always SIGTERM here — see
// runCommandSpawn) once timeoutMs elapses, so seeing that signal back means we timed out, not a
// crash. But `claude`'s compiled native binary CATCHES SIGTERM and exits with numeric code 143
// (128+15) instead of dying by signal — so a run we killed for running too long can show up as
// `code=143, signal=null`, which reads exactly like a plain nonzero-exit crash unless callers also
// check for 143. killSignal:SIGTERM is the only signal this module ever sends a child, so either
// tell means our own timeout fired.
export function isSpawnTimeout(code: number | null, signal: NodeJS.Signals | null): boolean {
  return signal === "SIGTERM" || code === 143;
}

// The stream-reading half of runCommandSpawn, split out so its rules are testable without a real
// subprocess (the repo's standing "pure helper, injectable seam" convention). Three rules live
// here, all three of them bugs that shipped:
//
// 1. ONLY STDOUT IS MARKER-PARSED. The protocol puts markers on stdout, so a stderr warning that
//    happens to read `STEP 1/3 ...` can never forge a step Muxin then trusts as measured progress.
// 2. THE RESIDUAL IS PER STREAM. Markers are parsed per LINE, so a marker split across chunks is
//    held back until its newline arrives. One residual buffer SHARED between the two streams was
//    the corruption: stdout wrote `STEP 1/3 Read` with no trailing newline, stderr wrote `warn`
//    next, the residual became `STEP 1/3 Readwarn`, and the step was lost. stderr keeps no
//    residual at all now.
// 3. A MARKER-EXEMPT KIND GETS NO PARSING AT ALL. See MARKER_EXEMPT_KINDS.
//
// The heartbeat deliberately still reads BOTH streams, unchanged: it is free-form progress text
// rather than a protocol, so a skill that logs its progress to stderr should still show a live
// line.
export function createSpawnStreamReader(
  job: Pick<Job, "kind" | "lastStdoutLine"> & MarkerTarget,
): { stdout(text: string): void; stderr(text: string): void; close(): string } {
  let tailBuf = "";
  let stdoutBuf = "";
  let residual = "";
  const parseMarkers = !MARKER_EXEMPT_KINDS.has(job.kind);
  const heartbeat = (text: string) => {
    tailBuf = (tailBuf + text).slice(-4000); // bounded tail buffer: the heartbeat only needs the last line
    const line = lastNonEmptyLine(tailBuf);
    if (line) job.lastStdoutLine = line;
  };
  return {
    stdout(text) {
      heartbeat(text);
      stdoutBuf += text;
      if (!parseMarkers) return;
      const lines = (residual + text).split("\n");
      residual = lines.pop() ?? "";
      if (lines.length) ingestMarkerChunk(job, lines.join("\n"));
    },
    stderr(text) {
      heartbeat(text); // and nothing else, on purpose
    },
    close() {
      // A final stdout line with no trailing newline still counts as a marker.
      if (residual) {
        ingestMarkerChunk(job, residual);
        residual = "";
      }
      return stdoutBuf;
    },
  };
}

export function runCommandSpawn(
  job: Job,
  command: string,
  args: string[],
  opts: { timeoutMs: number; env?: NodeJS.ProcessEnv; input?: string }
): Promise<CommandSpawnResult> {
  // A stopped job's future spawns are stillborn. A task job stopped between two spawns has no
  // child to signal, so stopJob settles it and hands the lane on immediately — without this guard
  // the orphaned closure could still spawn `claude` alongside the next job and break the
  // GUI-wide "one Claude at a time" bound this module's whole `draining` mutex exists to hold.
  if (job.stoppedByMuxin) {
    return Promise.resolve({ code: null, timedOut: false, enoent: false, stdout: "" });
  }
  mkdirSync(JOB_LOG_DIR, { recursive: true });
  const log = createWriteStream(jobLogPath(job.id), { flags: "a" });
  const reader = createSpawnStreamReader(job);
  const onChunk = (isStdout: boolean) => (chunk: Buffer) => {
    log.write(chunk);
    const text = chunk.toString("utf8");
    if (isStdout) reader.stdout(text);
    else reader.stderr(text);
  };
  return new Promise((resolve) => {
    const child = spawn(command, args, {
      cwd: repoRoot,
      timeout: opts.timeoutMs,
      killSignal: "SIGTERM",
      // Explicitly close the child's stdin (rather than leaving Node's default open, unwritten
      // pipe) — no caller here ever writes to it, but an unclosed pipe makes `claude -p` wait up
      // to 3s for stdin input before it warns and proceeds without it ("no stdin data received in
      // 3s"). Closing it up front skips that wait entirely.
      stdio: [opts.input === undefined ? "ignore" : "pipe", "pipe", "pipe"],
      env: { ...process.env, ...opts.env },
    });
    if (opts.input !== undefined && child.stdin) {
      child.stdin.end(opts.input);
    }
    // The only handle stopJob has to signal. Internal — publicJob never serializes it.
    job.proc = child;
    let enoent = false;
    child.on("error", (e) => {
      enoent = (e as { code?: string }).code === "ENOENT";
    });
    child.stdout?.on("data", onChunk(true));
    child.stderr?.on("data", onChunk(false));
    child.on("close", (code, signal) => {
      job.proc = undefined; // dead child, nothing left to signal
      // Flushes the last stdout line even without a trailing newline, and hands back everything
      // stdout said.
      const stdoutBuf = reader.close();
      // Wait for the write stream to actually flush before resolving — callers read the log file
      // back synchronously right after this promise settles (for the failure tail), and
      // log.end() alone doesn't guarantee the last chunk has hit disk yet.
      log.end(() => {
        const result = { code, timedOut: isSpawnTimeout(code, signal), enoent, stdout: stdoutBuf };
        // Remembered so settleJob can classify the outcome once, in one place.
        job.lastSpawn = { code: result.code, timedOut: result.timedOut, enoent: result.enoent };
        resolve(result);
      });
    });
  });
}

/** Spawn the selected agent through the same persisted log/heartbeat lane as Claude did. */
export async function runAgentSpawn(
  job: Job,
  engine: Engine,
  prompt: string,
  opts: EngineSpawnOptions & { env?: NodeJS.ProcessEnv },
): Promise<CommandSpawnResult> {
  const outputFile = engine === "codex"
    ? join(tmpdir(), `content-agents-${job.id}-${randomUUID()}.md`)
    : undefined;
  const built = buildEngineSpawn(engine, job.answer ? prompt + answerPromptSuffix(job.answer) : prompt, {
    ...opts,
    outputFile,
  });
  try {
    const result = await runCommandSpawn(job, built.command, built.args, {
      timeoutMs: opts.timeoutMs,
      env: { ...opts.env, CONTENT_AGENT_ENGINE: engine },
    });
    logCost({ step: `agent:${engine}`, detail: job.label, engine });
    if (!outputFile) return result;
    let finalMessage = "";
    try {
      finalMessage = readFileSync(outputFile, "utf8").trim();
    } catch {
      // The command's stdout remains useful for a failure log when Codex did not write a final answer.
    }
    return finalMessage ? { ...result, stdout: finalMessage } : result;
  } finally {
    if (outputFile) rmSync(outputFile, { force: true });
  }
}

// Pure argv builder for runClaudeSpawn, split out so a caller's exact invocation is unit-testable
// without spawning a real subprocess. `permissionMode: null` omits the --permission-mode flag
// entirely (draft.ts's callClaudeDraft never passes one, using --model/--tools instead — see
// enqueueFollowUpDraft below); omitting the option (undefined) keeps the original "acceptEdits"
// default so every pre-existing caller is unaffected.
export function buildClaudeSpawnArgs(
  prompt: string,
  opts: { permissionMode?: string | null; model?: string; tools?: string }
): string[] {
  const args = ["-p", prompt];
  if (opts.permissionMode !== null) args.push("--permission-mode", opts.permissionMode ?? "acceptEdits");
  if (opts.model !== undefined) args.push("--model", opts.model);
  if (opts.tools !== undefined) args.push("--tools", opts.tools);
  return args;
}

// `claude -p "<prompt>"` specifically, layered on runCommandSpawn above.
export function runClaudeSpawn(
  job: Job,
  prompt: string,
  opts: { timeoutMs: number; permissionMode?: string | null; model?: string; tools?: string; env?: NodeJS.ProcessEnv }
): Promise<CommandSpawnResult> {
  // Kept as a compatibility wrapper for existing callers. The job's selected engine is what
  // actually runs, so older call sites keep their name while picker-backed jobs can use Grok or
  // Codex without duplicating every task implementation.
  return runAgentSpawn(job, job.engine ?? "claude", prompt, opts);
}

// Last ~30 lines of a job's persisted log, formatted as a "\n---\n<tail>" suffix to append to an
// error message — or "" if there's no log to read yet. Shared by every failure path below so a
// failed job's error always points at what actually happened, not just an exit code.
export function logTailSuffix(jobId: string): string {
  try {
    const tail = tailLines(readFileSync(jobLogPath(jobId), "utf8"), 30);
    return tail ? `\n---\n${tail}` : "";
  } catch {
    return "";
  }
}

// The ONE enoent/timedOut/non-zero-exit classification for a runClaudeSpawn() result, shared by
// every Claude-spawning call site in the GUI (reviseDerivative, reviseBrief, duplicateToPlatform,
// generateInsights/askInsights in serve.ts, runVideoJob, and drain()'s atomize branch — previously
// six near-duplicated if/else-if chains, one per call site). Returns the failure message the caller
// should throw or assign, or null when the run was clean (exit 0, no timeout/enoent) so the caller
// proceeds to its own success-path work.
//
// Call sites disagree on wording, not on the underlying decoding, so the differences are captured
// as options rather than papered over:
// - `timeoutVerb`/`exitVerb` let a site's timeout and exit-code messages use different verbs (e.g.
//   reviseDerivative says "Claude timed out" but "Claude revise failed").
// - `timeoutLabel` is the pre-formatted duration ("180s" vs "15 min") since sites disagree on unit.
// - `includeTailOnTimeout` preserves an existing quirk: the assign-style sites (runVideoJob, the
//   atomize branch of drain()) append the log tail to the timeout message too, while the throw-style
//   sites (revise/insights/duplicate) don't. Preserved as-is — this is a pure extraction, not a
//   behavior change.
// - `command` names the binary in the ENOENT message; defaults to "claude" since every pre-existing
//   call site spawns `claude` — pullFreshAnalytics (serve.ts) is the first non-claude spawn through
//   this decoder (`npm`) and passes it explicitly so a missing-npm error doesn't blame `claude`.
export function decodeSpawnFailure(
  result: { code: number | null; timedOut: boolean; enoent: boolean },
  jobId: string,
  opts: { timeoutVerb: string; timeoutLabel: string; exitVerb: string; includeTailOnTimeout?: boolean; command?: string }
): string | null {
  if (result.enoent) {
    // `command` names the actual spawned CLI (runCommandSpawn call sites, e.g. "npm") — the
    // default stays "claude" so every pre-existing call site's message is unchanged.
    const cli = opts.command ?? "claude";
    return `the \`${cli}\` CLI isn't on this server's PATH — start the GUI from a terminal where \`${cli}\` runs`;
  }
  if (result.timedOut) {
    const tail = opts.includeTailOnTimeout ? logTailSuffix(jobId) : "";
    return `${opts.timeoutVerb} timed out after ${opts.timeoutLabel}${tail}`;
  }
  if (result.code !== 0) {
    return `${opts.exitVerb} failed (exit ${result.code})${logTailSuffix(jobId)}`;
  }
  return null;
}

// How a raw source string should reach /atomize. Exported + `exists` injected so it's unit-testable
// without touching the filesystem.
export function classifySource(
  raw: string,
  exists: (p: string) => boolean = existsSync,
): { kind: "url" | "file" | "file-not-found" | "text"; arg: string; label: string } {
  const s = raw.trim();
  if (/^https?:\/\//i.test(s)) return { kind: "url", arg: s, label: s };
  const asPath = s.startsWith("~/") ? join(homedir(), s.slice(2)) : s;
  // A short single-line string that resolves to a real file is a path (e.g. an Obsidian note).
  if (s && !s.includes("\n") && s.length < 400 && exists(asPath)) {
    return { kind: "file", arg: asPath, label: basename(asPath) };
  }
  // A string that LOOKS like a path (a slash with no spaces, a `~/` prefix, or a drive letter)
  // but doesn't resolve is a typo'd path, not pasted note content — say so fast instead of
  // materializing the raw string as fake note content and burning an LLM atomize run on it.
  const looksLikePath =
    s && !s.includes("\n") && s.length < 400 &&
    (s.startsWith("~/") || /^[A-Za-z]:[\\/]/.test(s) || (s.includes("/") && !s.includes(" ")));
  if (looksLikePath) {
    return { kind: "file-not-found", arg: asPath, label: basename(asPath) };
  }
  const firstLine = s.split("\n").map((l) => l.trim()).find(Boolean) ?? "pasted text";
  return { kind: "text", arg: "", label: firstLine.replace(/^#\s*/, "").slice(0, 80) };
}

// Turns a classifySource() result into either a dispatch descriptor for addJob() or an immediate
// client-facing error — kept separate from the /api/atomize route handler so the file-not-found
// short circuit is unit-testable without spinning up the HTTP server.
export function sourceDispatch(
  c: ReturnType<typeof classifySource>,
  rawText: string,
): { error: string } | { kind: AtomizeFamilyKind; arg: string; label: string; rawText?: string } {
  if (c.kind === "file-not-found") {
    return { error: `no such file: ${c.arg}` };
  }
  if (c.kind === "text") {
    return { kind: "text", arg: "", label: c.label, rawText };
  }
  return { kind: c.kind, arg: c.arg, label: c.label };
}

// Wall-clock time the job has taken so far — still ticking while running, frozen once it lands.
// A `blocked` job freezes exactly like `done`: it stopped at the moment it asked, and the time
// Muxin takes to answer is not time the job spent working.
export function jobElapsedMs(j: Pick<Job, "status" | "startedAt" | "finishedAt">, now: number = Date.now()): number | null {
  if (!j.startedAt) return null;
  return (j.status === "running" ? now : j.finishedAt ?? now) - j.startedAt;
}

// The polled read shape — an explicit allowlist, so internals (`task`, `lastSpawn`, the requeue
// recipe) can never leak into /api/jobs. The additions below are additive: every pre-existing
// field keeps its exact name and value.
export function publicJob(j: Job) {
  return {
    id: j.id, kind: j.kind, label: j.label, engine: j.engine ?? "claude", status: j.status, slugs: j.slugs,
    error: j.error, createdAt: j.createdAt, startedAt: j.startedAt, finishedAt: j.finishedAt,
    elapsedMs: jobElapsedMs(j), lastStdoutLine: j.lastStdoutLine,
    steps: j.steps, stepTotal: j.stepTotal, step: j.step, failedAtStep: j.failedAtStep,
    retryable: j.retryable, ask: j.ask, answer: j.answer,
    // The UI pairs elapsed time with a link to the run's log; without this the link has no href.
    logPath: jobLogPath(j.id),
  };
}

function listSlugs(): string[] {
  try {
    return readdirSync(CONTENT, { withFileTypes: true })
      .filter((d) => d.isDirectory() && existsSync(join(CONTENT, d.name, "review-queue.md")))
      .map((d) => d.name);
  } catch {
    return [];
  }
}

// Atomize-family job kinds: url/file/text/notes/continue dispatch `/atomize <arg>`; video
// dispatches `/video <arg>` instead. Both are verified by artifact (not exit code) in drain() below.
type AtomizeFamilyKind = "url" | "file" | "text" | "notes" | "continue" | "video";

// Copy a pasted-text or file source into .inbox under a stable, space-free name so the skill's
// `npm run new-content -- <arg>` never trips over spaces in an Obsidian path. Shared by addJob
// (atomize family) and addDevelopJob — the same door, two destinations.
function materializeInboxArg(kind: "text" | "file", rawArg: string, id: string, rawText?: string): string {
  mkdirSync(INBOX, { recursive: true });
  if (kind === "text") {
    const arg = join(INBOX, `${id}.md`);
    writeFileSync(arg, (rawText ?? "").trim() + "\n");
    return arg;
  }
  const content = readFileSync(rawArg, "utf8");
  const stem = basename(rawArg).replace(/\.[^.]+$/, "");
  const safe = stem.replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").toLowerCase() || "note";
  const arg = join(INBOX, `${safe}-${id}.md`);
  // Keep the note's title: if it has no heading, seed one from the filename so the skill doesn't
  // fall back to the safe filename.
  writeFileSync(arg, (/^#\s+/m.test(content) ? "" : `# ${stem}\n\n`) + content);
  return arg;
}

// Materialize a source into a stable, space-free arg for /atomize, then queue it. Pasted text and
// file sources are copied into .inbox (space-free names) via materializeInboxArg; urls and "notes"
// pass straight through. "video" jobs pass their content-folder path straight through too (see
// addVideoJob) — no materialization needed.
export function addJob(kind: AtomizeFamilyKind, rawArg: string, label: string, rawText?: string, engine: Engine = "claude"): Job {
  const id = nextJobId();
  const arg = kind === "text" || kind === "file" ? materializeInboxArg(kind, rawArg, id, rawText) : rawArg;
  const job: Job = { id, kind, label, arg, engine, ...freshJobFields() };
  jobs.push(job);
  void drain();
  return job;
}

// "Generate storyboard" (card 9e20a616): enqueue `/video <folder>` through the SAME queue atomize
// jobs run through — no second queue. Idempotent against a double-click: if this folder already
// has a video job queued/running, hand back that job instead of starting a redundant second /video.
export function addVideoJob(slug: string, engine: Engine = "claude"): Job {
  safeFolder(slug); // throws "no such queue" if slug isn't a real content folder
  const arg = join("content", slug);
  const existing = jobs.find((j) => j.kind === "video" && j.arg === arg && (j.status === "queued" || j.status === "running"));
  if (existing) return existing;
  return addJob("video", arg, `Generate storyboard: ${slug}`, undefined, engine);
}

// ── Develop tab: the advisor stage ──────────────────────────────────────────────────────────────
// `/develop <arg>` runs the advisor skill headlessly: it reads the source, runs the checks (brand
// angles, CTA sense-check, platform spin fit, routing preview) and appends a recommendation round
// to develop/advice.json + develop/log.md. It NEVER drafts a cut or a derivative — accept/dismiss
// are deterministic server-side actions (src/review/develop.ts), and formatting is a separate
// explicit "Format for platforms" click. Same queue, same artifact-verified contract.

// True while a develop/develop-reply job for this content folder is queued or running — the
// /api/develop/reply route refuses a second concurrent round for the same folder (409-style).
export function developJobInFlight(slug: string): boolean {
  const arg = join("content", slug);
  return jobs.some(
    (j) => (j.kind === "develop" || j.kind === "develop-reply") && j.arg === arg && (j.status === "queued" || j.status === "running"),
  );
}

// Start an advisor round. `source` uses the same classify/materialize door as /api/atomize (url /
// file / pasted text); an existing folder comes in as `{ slug }` instead. Reply rounds are
// enqueued by addDevelopReplyJob AFTER serve.ts persisted the reply to develop/log.md — the spawn
// argv stays a fixed `/develop content/<slug>`, no free text in it.
export function addDevelopJob(kind: "url" | "file" | "text", rawArg: string, label: string, rawText?: string, engine: Engine = "claude"): Job {
  const id = nextJobId();
  const arg = kind === "url" ? rawArg : materializeInboxArg(kind, rawArg, id, rawText);
  const job: Job = { id, kind: "develop", label: `Develop: ${label}`, arg, engine, ...freshJobFields() };
  jobs.push(job);
  void drain();
  return job;
}

export function addDevelopFolderJob(slug: string, kind: "develop" | "develop-reply" = "develop", engine: Engine = "claude"): Job {
  safeFolder(slug); // throws "no such queue" if slug isn't a real content folder
  const arg = join("content", slug);
  const existing = jobs.find(
    (j) => (j.kind === "develop" || j.kind === "develop-reply") && j.arg === arg && (j.status === "queued" || j.status === "running"),
  );
  if (existing) return existing; // idempotent against a double-click, like addVideoJob
  const label = kind === "develop-reply" ? `Advisor reply: ${slug}` : `Develop: ${slug}`;
  const job: Job = { id: nextJobId(), kind, label, arg, engine, ...freshJobFields() };
  jobs.push(job);
  void drain();
  return job;
}

// "Format for platforms" arg builder — pure, exported for a direct unit test. The extract lens is
// the top-level default (no cuts/ subfolder — src/atomize/cuts.ts), so it takes no --cut flag.
export function buildFormatArg(slug: string, lens: string): string {
  return lens === "extract" ? `--continue content/${slug}` : `--continue content/${slug} --cut ${lens}`;
}

// Parse a continue-job's arg back into its folder (+ optional cut lens). Pure + exported for unit
// tests; returns null on any shape this module didn't itself build.
export function parseContinueArg(arg: string): { folder: string; lens?: string } | null {
  const m = /^--continue\s+(\S+)(?:\s+--cut\s+(\S+))?\s*$/.exec(arg);
  if (!m) return null;
  if (m[2] !== undefined && !isValidLens(m[2])) return null;
  return m[2] ? { folder: m[1], lens: m[2] } : { folder: m[1] };
}

// Artifact snapshot for a continue job: how many queue rows the folder has, and how many files sit
// in the derivatives dir the job targets (top-level for extract, cuts/<lens>/derivatives for a
// cut). `deps` injected so the growth predicate is unit-testable without a real folder.
export interface ContinueArtifacts {
  rows: number;
  derivatives: number;
}
export function continueArtifactCounts(folderAbs: string, lens?: string): ContinueArtifacts {
  let rows = 0;
  try {
    rows = readQueue(folderAbs).rows.length;
  } catch {
    /* no queue yet — counts as 0 */
  }
  const derivDir = lens ? join(folderAbs, "cuts", lens, "derivatives") : join(folderAbs, "derivatives");
  let derivatives = 0;
  try {
    derivatives = readdirSync(derivDir).length;
  } catch {
    /* dir not created yet — counts as 0 */
  }
  return { rows, derivatives };
}
export function continueJobProgressed(before: ContinueArtifacts, after: ContinueArtifacts): boolean {
  return after.rows > before.rows || after.derivatives > before.derivatives;
}

interface AtomizeRunResult {
  code: number | null;
  timedOut: boolean;
  enoent: boolean;
}

// Spawn the real /atomize headlessly. ATOMIZE_ORIGIN=gui-queue tells the /atomize skill's step 8
// to tag every row it appends "from GUI queue" instead of the default "from /cycle" — the origin
// source-tag the review GUI renders per row (src/publish/queue.ts QUEUE_ORIGINS).
async function runAtomizeJob(job: Job): Promise<AtomizeRunResult> {
  const result = await runClaudeSpawn(job, enginePrompt(job.engine ?? "claude", "atomize", `/atomize ${job.arg}`), {
    timeoutMs: ATOMIZE_TIMEOUT_MS,
    permissionMode: ATOMIZE_PERMISSION_MODE,
    env: { ATOMIZE_ORIGIN: "gui-queue" },
  });
  return { code: result.code, timedOut: result.timedOut, enoent: result.enoent };
}

// Spawn `/video <folder>` headlessly and verify success by artifact (video/storyboard.md actually
// existing), not exit code — the same "finished" != "worked" fix complaint 4 required for atomize.
// Sets job.status/job.error/job.slugs itself (mirrors the atomize branch of drain() below).
async function runVideoJob(job: Job): Promise<void> {
  const folderAbs = join(repoRoot, job.arg);
  const result = await runClaudeSpawn(job, enginePrompt(job.engine ?? "claude", "video", `/video ${job.arg}`), {
    timeoutMs: ATOMIZE_TIMEOUT_MS,
    permissionMode: ATOMIZE_PERMISSION_MODE,
  });
  const failure = decodeSpawnFailure(result, job.id, {
    timeoutVerb: "video generation", timeoutLabel: `${ATOMIZE_TIMEOUT_MS / 60000} min`,
    exitVerb: "video generation", includeTailOnTimeout: true,
  });
  const storyboardReady = existsSync(join(folderAbs, "video", "storyboard.md"));
  job.status = !failure && storyboardReady ? "done" : "failed";
  if (job.status === "done") {
    job.slugs = [basename(job.arg)]; // enables the jobs pill's "→ review" jump link
    return;
  }
  job.error = failure ?? `/video ran but produced no video/storyboard.md — check the view-log link${logTailSuffix(job.id)}`;
}

// Spawn `/develop <arg>` headlessly and verify by artifact: a NEW, parseable round must have
// landed in develop/advice.json (roundCount uses the tolerant readAdvice parse, so a run that
// exits 0 but writes garbage JSON still fails loudly here instead of rendering nothing). For a
// start-from-source job the folder doesn't exist yet — diff listSlugs() like the atomize branch,
// then check the new folder's round count against 0.
const DEVELOP_TIMEOUT_MS = 10 * 60_000;
async function runDevelopJob(job: Job): Promise<void> {
  const isFolderArg = job.arg.startsWith("content/");
  const beforeSlugs = isFolderArg ? null : new Set(listSlugs());
  const beforeRounds = isFolderArg ? roundCount(join(repoRoot, job.arg)) : 0;
  const result = await runClaudeSpawn(job, enginePrompt(job.engine ?? "claude", "develop", `/develop ${job.arg}`), {
    timeoutMs: DEVELOP_TIMEOUT_MS,
    permissionMode: ATOMIZE_PERMISSION_MODE,
  });
  const failure = decodeSpawnFailure(result, job.id, {
    timeoutVerb: "the advisor", timeoutLabel: `${DEVELOP_TIMEOUT_MS / 60000} min`,
    exitVerb: "the advisor", includeTailOnTimeout: true,
  });
  let slug: string | null = isFolderArg ? basename(job.arg) : null;
  if (!isFolderArg) {
    const created = listSlugs().filter((s) => !beforeSlugs!.has(s));
    // Prefer the created folder that actually carries an advisor round; fall back to any created.
    slug = created.find((s) => roundCount(join(CONTENT, s)) > 0) ?? created[0] ?? null;
  }
  const rounds = slug ? roundCount(isFolderArg ? join(repoRoot, job.arg) : join(CONTENT, slug)) : 0;
  job.status = !failure && slug && rounds > beforeRounds ? "done" : "failed";
  if (job.status === "done") {
    job.slugs = [slug!];
    return;
  }
  job.error = failure ?? `the advisor ran but wrote no new round to develop/advice.json — check the view-log link${logTailSuffix(job.id)}`;
}

// A `--continue` job runs on an ALREADY-scaffolded folder, so drain()'s new-folder diff can never
// see it — before this branch existed, a perfectly clean continue run finished with a misleading
// "created no new content folder" error and no "→ review" link (hit by both the notes-pick flow
// and the Develop tab's Format for platforms). Verified instead by in-folder artifact: queue rows
// or the targeted derivatives dir grew.
async function runContinueJob(job: Job): Promise<void> {
  const parsed = parseContinueArg(job.arg);
  const folderAbs = parsed ? join(repoRoot, parsed.folder) : null;
  const before = folderAbs ? continueArtifactCounts(folderAbs, parsed?.lens) : null;
  const result = await runAtomizeJob(job);
  const failure = decodeSpawnFailure(result, job.id, {
    timeoutVerb: "atomize", timeoutLabel: `${ATOMIZE_TIMEOUT_MS / 60000} min`,
    exitVerb: "atomize", includeTailOnTimeout: true,
  });
  // An unparseable arg (not built by this module) degrades to exit-code-only verification rather
  // than failing a run we can't inspect.
  const progressed =
    !folderAbs || !before ? true : continueJobProgressed(before, continueArtifactCounts(folderAbs, parsed?.lens));
  job.status = !failure && progressed ? "done" : "failed";
  if (job.status === "done") {
    if (parsed) job.slugs = [basename(parsed.folder)]; // enables the jobs pill's "→ review" jump link
    if (folderAbs) stampFolderEngine(folderAbs, job.engine ?? "claude");
    return;
  }
  job.error =
    failure ??
    `formatting ran but added no new rows or derivatives in ${parsed?.folder ?? job.arg} — check the view-log link${logTailSuffix(job.id)}`;
}


// ── Fiction: draft a scene, check it against canon (Build 2) ─────────────────────────────────────
// Two job kinds, both landing in the Fiction room.
//
// WHY "Draft it" DISPATCHES THE /story SKILL RATHER THAN story:draft. src/fiction/draft.ts is inert
// for the common case: whenever a series' series.yaml says `prose: claude-native` (the default, and
// what the only series here uses) it exits 1 with "chapters are composed by the /story skill (Opus
// plans, sonnet writes), not by this script". It is also a guardrail path. So the composer routes
// through `/story <series>` headlessly, the same way addJob dispatches `/atomize <arg>`, and
// draft.ts is left untouched.
//
// TWO THINGS THE DISPATCH PROMPT CONSTRAINS, both stated in place rather than by editing the skill:
// 1. The skill's step 2 is a beat-sheet approval gate that posts the beats and STOPS for Muxin's
//    sign-off. In the studio she typed the beats herself and pressed "Draft it", so the sign-off on
//    direction already happened; a headless run that waited for it would just time out. The chapter
//    itself still waits for her: nothing here approves, locks or publishes anything.
// 2. The skill's step 7 commits the chapter on a branch and opens a draft PR. A GUI button doing
//    git work in the live checkout is not something this room should do on its own, and the design
//    is explicit that "line editing and the commit history stay in your GitHub flow". So the run is
//    told to stop after validate.
const FICTION_TIMEOUT_MS = 20 * 60_000;
const CONTINUITY_TIMEOUT_MS = 10 * 60_000;

// Pure prompt assembly, exported so the two constraints above are directly readable in a test.
export function fictionDraftPrompt(slug: string, beats: string): string {
  return [
    `/story ${slug}`,
    ``,
    `Muxin typed these beats in the studio's Fiction room and pressed "Draft it". They are her`,
    `direction for this scene:`,
    `"""`,
    beats.trim(),
    `"""`,
    ``,
    `This run is headless, so three things differ from the interactive skill:`,
    `- Her beats above ARE her sign-off on the direction, so do not post a beat sheet and wait.`,
    `  Plan from them and draft the chapter now.`,
    `- Write chapters/chapter-NN.md and run story:validate. Stop there.`,
    `- Do NOT commit, branch, push or open a pull request, and do not lock or publish anything.`,
    `  She reads the scene in the studio first, and the GitHub flow stays hers.`,
  ].join("\n");
}

// The second pass. `/story --revise` normally reads Muxin's GitHub PR review comments, and there is
// no PR here, so the note is handed over as the one review comment it should work from.
export function fictionRepassPrompt(slug: string, chapter: number, note: string): string {
  return [
    `/story --revise ${slug} ${chapter}`,
    ``,
    `There is no GitHub pull request for this chapter yet, so there are no review comments to read.`,
    `Muxin's note, typed in the studio, is the one comment. It covers the whole chapter:`,
    `"""`,
    note.trim(),
    `"""`,
    ``,
    `Apply it the way the skill's revise rules say: edits in the direction she asked for, and leave`,
    `everything her note does not reach. Re-run story:validate when you are done.`,
    `Do NOT commit, branch, push, open a pull request or reply on any thread. She reads the result`,
    `in the studio.`,
  ].join("\n");
}

// Every chapter's prose, keyed by number — the before/after artifact check for a fiction run.
// "Finished" is not "worked": a /story run can exit 0 having written nothing, and the only honest
// proof is a chapter file that appeared or changed.
export function chapterSnapshot(dir: string): Map<number, string> {
  const snap = new Map<number, string>();
  for (const n of chapterNumbers(dir)) {
    try {
      snap.set(n, readChapter(dir, n).body);
    } catch {
      /* unreadable mid-write — counts as absent */
    }
  }
  return snap;
}

// Pure: what a fiction run actually produced, from the two snapshots. Returns the chapter number a
// draft created, or null when nothing landed. Exported so the artifact check is unit-testable
// without spawning anything.
export function fictionRunProduced(
  before: Map<number, string>,
  after: Map<number, string>,
  mode: "draft" | "repass",
  target?: number,
): number | null {
  if (mode === "draft") {
    const fresh = [...after.keys()].filter((n) => !before.has(n)).sort((a, b) => a - b);
    return fresh.length ? fresh[fresh.length - 1] : null;
  }
  if (!target) return null;
  const was = before.get(target);
  const now = after.get(target);
  if (now === undefined || was === undefined) return null;
  return now !== was ? target : null;
}

// Which queued-or-running fiction job a new request is a duplicate of. Pure over the list so the
// identity rule is unit-testable without pushing a job (a pushed job starts a real `claude` spawn).
//
// Identity is the WHOLE request, not the series. Matching on kind and series alone meant a queued
// first-pass draft swallowed a chapter-3 second pass, and a chapter-3 second pass swallowed a
// chapter-5 one: the route answered ok with somebody else's job and the run Muxin asked for never
// happened.
export function findFictionDupe(
  list: Job[],
  want: { kind: Job["kind"]; series: string; mode?: string; chapter?: number },
): Job | undefined {
  return list.find((j) => {
    if (j.kind !== want.kind) return false;
    if (j.status !== "queued" && j.status !== "running") return false;
    const p = j.payload ?? {};
    if (p.series !== want.series) return false;
    if (want.mode !== undefined && (p.mode ?? "draft") !== want.mode) return false;
    if (want.chapter !== undefined && p.chapter !== want.chapter) return false;
    return true;
  });
}

export function addFictionDraftJob(seriesArg: string, beats: string, engine: Engine = "claude"): { job: Job; queued: boolean } {
  const dir = resolveSeriesDir(seriesArg); // throws on an unknown series before anything is queued
  const slug = basename(dir);
  if (!beats.trim()) throw new Error("say the beats first");
  const existing = findFictionDupe(jobs, { kind: "fiction-draft", series: slug, mode: "draft" });
  // Idempotent against a double-click, like addVideoJob. `queued: false` tells the route this run
  // is somebody else's already in flight, so it must not overwrite the beats anchor with beats the
  // running job never received.
  if (existing) return { job: existing, queued: false };
  const job: Job = {
    id: nextJobId(), kind: "fiction-draft", label: `Draft a scene: ${slug}`, arg: slug, engine, ...freshJobFields(),
    payload: { mode: "draft", series: slug, beats: beats.trim() },
  };
  jobs.push(job);
  void drain();
  return { job, queued: true };
}

export function addFictionRepassJob(seriesArg: string, chapter: number, note: string, engine: Engine = "claude"): Job {
  const dir = resolveSeriesDir(seriesArg);
  const slug = basename(dir);
  if (!note.trim()) throw new Error("say what to change first");
  if (!chapterNumbers(dir).includes(chapter)) throw new Error(`there is no chapter ${chapter} to run again`);
  const existing = findFictionDupe(jobs, { kind: "fiction-draft", series: slug, mode: "repass", chapter });
  if (existing) return existing;
  const job: Job = {
    id: nextJobId(), kind: "fiction-draft", label: `Second pass: ${slug} chapter ${chapter}`, arg: slug, engine, ...freshJobFields(),
    payload: { mode: "repass", series: slug, chapter, note: note.trim() },
  };
  jobs.push(job);
  void drain();
  return job;
}

export function addFictionCheckJob(seriesArg: string, chapter: number, engine: Engine = "claude"): Job {
  const dir = resolveSeriesDir(seriesArg);
  const slug = basename(dir);
  if (!chapterNumbers(dir).includes(chapter)) throw new Error(`there is no chapter ${chapter} to check`);
  const existing = findFictionDupe(jobs, { kind: "fiction-continuity", series: slug, chapter });
  if (existing) return existing;
  const job: Job = {
    id: nextJobId(), kind: "fiction-continuity", label: `Check the canon: ${slug} chapter ${chapter}`,
    arg: slug, engine, ...freshJobFields(), payload: { series: slug, chapter, engine },
  };
  jobs.push(job);
  void drain();
  return job;
}

// ── The "do not touch git" rule, enforced rather than asked for ─────────────────────────────────
// The /story skill's step 7 commits the chapter on a branch and opens a draft PR, and the dispatch
// prompt tells the headless run not to. A prompt is a request. The run holds `acceptEdits` and it
// legitimately needs Bash for `npm run story:validate`, so no tool filter can take git away from it
// without also taking the validate step away. What CAN be enforced is the outcome: read where git
// stands before the run and again after, and fail the job loudly if anything moved. That covers
// every route to the same damage (a commit, a checkout, a new branch) instead of naming commands.
//
// It never reverts. Rewinding somebody's checkout to clean up after a bad run is a worse failure
// than the one it fixes; the job reports exactly what moved and leaves it to Muxin.
export interface GitState {
  head: string; // HEAD commit sha
  branch: string; // current branch name, or "HEAD" when detached
  branches: string; // every local branch, newline joined
}

export function readGitState(cwd: string = repoRoot): GitState | null {
  const run = (args: string[]) => execFileSync("git", args, { cwd, encoding: "utf8", timeout: 15_000 }).trim();
  try {
    return {
      head: run(["rev-parse", "HEAD"]),
      branch: run(["rev-parse", "--abbrev-ref", "HEAD"]),
      branches: run(["for-each-ref", "--format=%(refname)", "refs/heads"]),
    };
  } catch {
    return null; // not a git checkout, or git is unavailable: there is nothing to compare
  }
}

// Pure: what moved, in Muxin's words. Null when git stands exactly where it did.
export function gitStateDrift(before: GitState | null, after: GitState | null): string | null {
  if (!before || !after) return null;
  const moved: string[] = [];
  if (before.branch !== after.branch) moved.push(`it switched the branch from ${before.branch} to ${after.branch}`);
  if (before.head !== after.head) moved.push("it committed something");
  const fresh = after.branches.split("\n").filter((b) => b && !before.branches.split("\n").includes(b));
  if (fresh.length) moved.push(`it created ${fresh.map((b) => b.replace("refs/heads/", "")).join(", ")}`);
  if (!moved.length) return null;
  return `the run was told to leave git alone and did not: ${moved.join(", ")}. Nothing was undone for you, so check \`git status\` and \`git log\` before you carry on.`;
}

async function runFictionDraftJob(job: Job): Promise<void> {
  const p = job.payload ?? {};
  const mode = p.mode === "repass" ? "repass" : "draft";
  const dir = resolveSeriesDir(p.series ?? job.arg);
  const before = chapterSnapshot(dir);
  const gitBefore = readGitState();
  const prompt =
    mode === "repass"
      ? fictionRepassPrompt(p.series ?? job.arg, p.chapter ?? 0, p.note ?? "")
      : fictionDraftPrompt(p.series ?? job.arg, p.beats ?? "");

  const result = await runClaudeSpawn(job, prompt, {
    timeoutMs: FICTION_TIMEOUT_MS,
    permissionMode: ATOMIZE_PERMISSION_MODE,
  });
  const failure = decodeSpawnFailure(result, job.id, {
    timeoutVerb: mode === "repass" ? "the second pass" : "the scene draft",
    timeoutLabel: `${FICTION_TIMEOUT_MS / 60000} min`,
    exitVerb: mode === "repass" ? "the second pass" : "the scene draft",
    includeTailOnTimeout: true,
  });
  const produced = fictionRunProduced(before, chapterSnapshot(dir), mode, p.chapter);
  const drift = gitStateDrift(gitBefore, readGitState());
  job.status = !failure && produced !== null && !drift ? "done" : "failed";
  if (produced === null || job.status !== "done") {
    // A chapter that landed AND git that moved is both facts at once, and the run still failed.
    const landed = produced === null ? "" : ` Chapter ${produced} was written, so the prose is on disk.`;
    job.error =
      failure ??
      (drift
        ? `${drift}${landed}${logTailSuffix(job.id)}`
        : mode === "repass"
          ? `the second pass ran but chapter ${p.chapter} did not change, so nothing was written${logTailSuffix(job.id)}`
          : `it ran but wrote no new chapter file, so nothing was written${logTailSuffix(job.id)}`);
    return;
  }
  const chapter: number = produced;
  job.payload = { ...p, chapter };
  // Keep the anchor pointing at the scene it produced, so a reload still shows her beats above it.
  try {
    if (mode === "draft" && p.beats) saveSceneBeats(p.series ?? job.arg, p.beats, chapter);
  } catch {
    /* the anchor is a convenience; a scene that exists is still a scene */
  }
  // "It writes a first pass and checks the canon while it goes." The queue is serial, so this
  // simply runs next, on the same engine the draft ran on unless she picks a different one for the
  // recheck itself.
  try {
    addFictionCheckJob(p.series ?? job.arg, chapter, job.engine ?? "claude");
  } catch {
    /* a check that cannot be queued must not fail the draft that already landed */
  }
}

async function runFictionCheckJob(job: Job): Promise<void> {
  const p = job.payload ?? {};
  const slug = p.series ?? job.arg;
  const chapter = p.chapter ?? 0;
  const engine: Engine = p.engine ?? job.engine ?? "claude";
  const before = readContinuityReport(slug, chapter)?.checkedAt ?? null;
  const result = await runCommandSpawn(job, "npx", ["tsx", "src/fiction/continuity.ts", slug, "--chapter", String(chapter), "--engine", engine], {
    timeoutMs: CONTINUITY_TIMEOUT_MS,
  });
  const failure = decodeSpawnFailure(result, job.id, {
    timeoutVerb: `the ${ENGINE_LABELS[engine]} canon check`, timeoutLabel: `${CONTINUITY_TIMEOUT_MS / 60000} min`,
    exitVerb: `the ${ENGINE_LABELS[engine]} canon check`, includeTailOnTimeout: true, command: "npx",
  });
  // Artifact, not exit code: a fresh report actually on disk.
  const after = readContinuityReport(slug, chapter);
  const wrote = Boolean(after) && after!.checkedAt !== before;
  job.status = !failure && wrote ? "done" : "failed";
  if (job.status === "failed") {
    job.error = failure ?? `the canon check ran but wrote no findings to ${continuityReportPath(slug, chapter)}${logTailSuffix(job.id)}`;
  }
}

// The ONE place a job stops running. Every branch of drain() below routes through this instead of
// repeating the finishedAt/draining/drain() dance, so the three cross-cutting rules hold everywhere:
//
// 1. A deliberate ask wins over the artifact check. A subprocess that asks a question stops before
//    writing anything, so `runVideoJob`/`runDevelopJob`/`runContinueJob`/the atomize branch will all
//    have just marked it "failed" for producing no artifact. That verdict is wrong and its error
//    message is misleading, so a clean spawn carrying a real ask overrides both.
// 2. A blocked job RELEASES THE LANE. It sets finishedAt, drops `draining`, and kicks the next job.
//    Holding the lane for a human's answer would stall every job queued behind it.
// 3. A failure records where it died and whether Retry is worth offering.
function settleJob(job: Job): void {
  // RULE 0, checked before every other verdict: Muxin's Stop wins. `claude` catches SIGTERM and
  // exits 143 (see isSpawnTimeout), so the close handler hands back a failure-shaped result for a
  // run she deliberately ended — without this branch every Stop would render as "Did not work",
  // complete with a Retry button for a run that was not broken.
  if (job.stoppedByMuxin) {
    // A task-closure job has no child to signal, so stopJob settled it and handed the lane on the
    // moment she pressed the button. Its orphaned promise resolving later re-enters here with
    // drain() having just clobbered the status back to done/failed: re-force `stopped`, but do
    // NOT touch `draining` — a different job holds the lane now, and releasing it again would run
    // two jobs at once.
    const alreadySettled = job.finishedAt !== null;
    job.status = "stopped";
    job.error = null;
    // Retry's contract is "the run broke, the same attempt may work". A deliberate stop is not
    // that, and `retryable` is derived from a spawn result a stopped job never produces.
    job.retryable = false;
    job.failedAtStep = null;
    job.proc = undefined;
    if (alreadySettled) return;
    job.finishedAt = Date.now();
    draining = false;
    void drain(); // next queued job — the lane she just freed
    return;
  }
  // `job.status !== "done"` is the load-bearing half of rule 1. The override exists ONLY to rescue
  // a job the artifact check just marked failed because the subprocess asked instead of writing.
  // A skill that wrote its artifact AND printed an ask has already done the work, so flipping it
  // to blocked would ask Muxin a question about finished work and then, on her answer, re-run the
  // whole job and overwrite or duplicate what it produced.
  if (job.status !== "done" && shouldBlockOnAsk(job.ask, job.lastSpawn ?? null)) {
    job.status = "blocked";
    job.error = null; // the artifact check's "wrote nothing" verdict was about the ask, not a fault
  }
  if (job.status === "done" && job.stepTotal !== null) job.step = job.stepTotal;
  if (job.status === "failed") {
    // Null when the skill emitted no step markers: there is no step to point at, and a hard 0
    // would invent one.
    job.failedAtStep = job.stepTotal === null ? null : job.step;
    // No spawn result means the task threw before it ever spawned (a validation error, say) —
    // default to offering Retry rather than dead-ending a job we can't classify.
    job.retryable = job.lastSpawn ? isRetryableFailure(job.lastSpawn) : true;
  }
  job.finishedAt = Date.now();
  draining = false;
  void drain(); // next queued job
}

// The verdict for an atomize-family run. THE ARTIFACT CHECK DECIDES, NOT THE EXIT CODE: a run that
// exits 0 and creates no content folder wrote nothing, and calling that `done` put a green row, a
// "Content" rail, a "took 45s" clock and the landing sentence "A cut, waiting on your yes." on
// screen for a cut that does not exist. `failed` is also what makes settleJob mark it retryable
// (a clean exit is not ENOENT) and what lets Clear queue sweep it. runVideoJob, runDevelopJob and
// runContinueJob already worked this way; this is the branch that did not.
export function atomizeArtifactVerdict(failure: string | null, createdSlugs: number): "done" | "failed" {
  return !failure && createdSlugs > 0 ? "done" : "failed";
}

// Process the queue one job at a time — every kind (atomize-family AND task jobs) shares this one
// `draining` mutex, so GUI-wide Claude concurrency is bounded no matter which button fired it.
async function drain(): Promise<void> {
  if (draining) return;
  const job = jobs.find((j) => j.status === "queued");
  if (!job) return;
  draining = true;
  job.status = "running";
  job.startedAt = Date.now();

  if (job.task) {
    // Generic task job (revise/brief-revise/insights/ask-insights/duplicate). The task itself
    // already resolved/rejected runQueued()'s caller-facing promise; this just finishes bookkeeping.
    try {
      await job.task(job);
      job.status = "done";
    } catch {
      job.status = "failed"; // job.error was already set inside runQueued()'s wrapper
    }
    settleJob(job);
    return;
  }

  if (job.kind === "video") {
    await runVideoJob(job);
    settleJob(job);
    return;
  }

  if (job.kind === "fiction-draft") {
    await runFictionDraftJob(job);
    settleJob(job);
    return;
  }

  if (job.kind === "fiction-continuity") {
    await runFictionCheckJob(job);
    settleJob(job);
    return;
  }

  if (job.kind === "develop" || job.kind === "develop-reply") {
    await runDevelopJob(job);
    settleJob(job);
    return;
  }

  if (job.kind === "continue") {
    await runContinueJob(job);
    settleJob(job);
    return;
  }

  // Atomize-family (url/file/text/notes): diff the content folders before/after to link
  // the job to whatever it created (claude's stdout isn't reliable).
  const before = new Set(listSlugs());
  const result = await runAtomizeJob(job);
  job.slugs = listSlugs().filter((s) => !before.has(s)); // artifact check — real folders, not exit code
  const failure = decodeSpawnFailure(result, job.id, {
    timeoutVerb: "atomize", timeoutLabel: `${ATOMIZE_TIMEOUT_MS / 60000} min`,
    exitVerb: "atomize", includeTailOnTimeout: true,
  });
  job.status = atomizeArtifactVerdict(failure, job.slugs.length);
  if (job.status === "done") {
    // Belt-and-suspenders: force the origin tag on every row of every folder this job created,
    // rather than trusting the subprocess's own SKILL.md-driven bookkeeping to have landed it
    // (e.g. if `echo $ATOMIZE_ORIGIN` wasn't an allowlisted Bash command in that run).
    for (const slug of job.slugs) {
      try {
        stampOrigin(join(CONTENT, slug), "from GUI queue");
        stampFolderEngine(join(CONTENT, slug), job.engine ?? "claude");
      } catch {
        // best-effort tagging only — never fail the job over it
      }
    }
  } else {
    job.error = failure ?? `atomize finished but created no new content folder — check the view-log link${logTailSuffix(job.id)}`;
  }
  settleJob(job);
}

// ── Answering a blocked job, and retrying a failed one ──────────────────────────────────────────
// Both entry points live here rather than in serve.ts so the queue's invariants (what a job may be
// answered from, what a retry resets) stay next to drain(). The routes are thin wrappers.

// Muxin picked one of the options a blocked job offered. A dead subprocess cannot be resumed, so
// this REQUEUES A NEW JOB carrying her answer forward rather than faking a resume: same kind, same
// arg, same task closure, fresh id and fresh log. The answer reaches the new run's prompt through
// runClaudeSpawn (answerPromptSuffix). The job re-runs its early steps, which is the accepted
// tradeoff (v5 handoff §8.1).
//
// The original job stays `blocked` with `answer` recorded, so the question and what she chose are
// still readable. That also means it is never swept by clearFinishedJobs.
export function answerJob(id: string, answer: string): { error: string } | { job: Job } {
  const original = jobs.find((j) => j.id === id);
  if (!original) return { error: "no such job" };
  if (original.status !== "blocked" || !original.ask) return { error: "that job isn't waiting on an answer" };
  if (original.answer) return { error: "you already answered that one" };
  if (!original.ask.options.includes(answer)) return { error: "pick one of the options that job offered" };

  original.answer = answer;
  const job: Job = {
    ...freshJobFields(),
    id: nextJobId(),
    kind: original.kind,
    label: original.label,
    arg: original.arg,
    engine: original.engine ?? "claude",
    task: original.task,
    payload: original.payload,
    answer,
  };
  jobs.push(job);
  void drain();
  return { job };
}

// Muxin pressed Stop it. Three shapes of job, three different mechanics — and only one of them
// actually has a process to kill:
//
// 1. QUEUED: nothing was ever started, so there is nothing to signal. Mark it `stopped` and it is
//    simply never picked: drain() finds work with `jobs.find(status === "queued")`. Deliberately
//    NOT routed through settleJob — a queued job holds no lane, and settleJob's `draining = false`
//    would hand away a lane some OTHER job is actively running in.
// 2. RUNNING WITH A SUBPROCESS: flag it, then SIGTERM. The natural close -> run function -> drain
//    -> settleJob path finishes the job, and settleJob's rule 0 turns the exit-143 failure shape
//    back into `stopped`.
// 3. RUNNING A TASK CLOSURE (revise/insights/duplicate, mid-await between spawns): there is no
//    process. Stopping can only mean "mark it stopped and throw its result away" — so settle it
//    now, reject the caller's promise via `discard`, and let the orphan finish into nothing. The
//    stoppedByMuxin guard at the top of runCommandSpawn keeps that orphan from spawning `claude`
//    behind the next job's back.
//
// Anything already settled (done/failed/blocked/stopped) is a no-op: `stopped: false` back, status
// untouched. Stopping is not a way to dismiss an unanswered question — that would throw away the
// ask Muxin has not answered yet.
export function stopJob(id: string): { error: string } | { job: Job; stopped: boolean } {
  const job = jobs.find((j) => j.id === id);
  if (!job) return { error: "no such job" };
  if (job.status !== "queued" && job.status !== "running") return { job, stopped: false };

  job.stoppedByMuxin = true; // set BEFORE any signal — the settle path reads it first

  if (job.status === "queued") {
    job.status = "stopped";
    job.error = null;
    job.retryable = false;
    job.finishedAt = Date.now();
    job.discard?.(new Error("you stopped this one"));
    return { job, stopped: true };
  }

  if (job.proc) {
    try {
      job.proc.kill("SIGTERM"); // the only signal this module sends — see runCommandSpawn
    } catch {
      // already gone between the check and the kill; the close handler settles it either way
    }
    return { job, stopped: true };
  }

  job.discard?.(new Error("you stopped this one"));
  settleJob(job);
  return { job, stopped: true };
}

// Run a failed job again. Same job id on purpose: the log file opens in append mode, so the second
// attempt lands under the first in one readable history.
export function retryJob(id: string): { error: string } | { job: Job } {
  const job = jobs.find((j) => j.id === id);
  if (!job) return { error: "no such job" };
  if (job.status !== "failed") return { error: "only a failed job can be run again" };
  if (!job.retryable) return { error: "running that again can't fix it" };

  job.status = "queued";
  job.error = null;
  job.failedAtStep = null;
  job.step = 0;
  // The previous attempt's checklist goes with it. settleJob forces `step = stepTotal` on a clean
  // finish, so a leftover stepTotal would paint a full progress bar and a row of green step labels
  // for a checklist THIS attempt never emitted. Never render progress the system did not measure.
  job.steps = [];
  job.stepTotal = null;
  job.lastStdoutLine = null;
  // Both cleared so the clock restarts from the retry rather than showing the first attempt's
  // frozen elapsed while it sits queued.
  job.startedAt = null;
  job.finishedAt = null;
  // Stale state from the failed attempt would otherwise leak into settleJob's next verdict.
  job.ask = null;
  job.lastSpawn = undefined;
  void drain();
  return { job };
}

// ── Duplicate to platform ────────────────────────────────────────────────────────────────────
// The missing "create a post for another platform" affordance (card 9304e4a5: Muxin asked Ask
// Claude to turn a Bluesky post into an X post — out of Ask Claude's edit-in-place scope by
// design). This reuses the SAME spin config /atomize's own spin pass reads — resolveAngle() from
// src/atomize/spin.ts, the actual "spin path" — so the reframe follows the identical
// Muxin-approved per-platform angle rather than inventing a new one here. There's no separate
// callable "spin one derivative" function anywhere in the codebase (spin is Claude-driven, done
// inline during /atomize); this mirrors reviseDerivative's pattern (a scoped Claude subprocess)
// but WRITES A NEW FILE instead of editing one in place. Claude only ever touches that one new
// derivative file — the review-queue.md row is appended deterministically by this module
// afterward (queue.ts's appendRow), not trusted to the subprocess, the same "don't trust the
// subprocess's own bookkeeping" belt-and-suspenders pattern stampOrigin already uses above.
// Nothing here approves or schedules anything — the new row lands `pending`, gated by Muxin's
// review like every other row (CLAUDE.md rule 2).

// Next available `<platform>-N` id in folder's review-queue.md — mirrors how /atomize numbers
// derivative options (x-1, x-2, ...). Exported for a direct unit test.
export function nextDerivativeId(folder: string, platform: string): string {
  const { rows } = readQueue(folder);
  const re = new RegExp(`^${platform}-(\\d+)$`);
  const max = rows.reduce((m, r) => {
    const match = re.exec(r.id);
    return match ? Math.max(m, Number(match[1])) : m;
  }, 0);
  return `${platform}-${max + 1}`;
}

// Guards duplicateToPlatform's write: refuse instead of letting the claude subprocess silently
// clobber a stray file that happens to already occupy the freshly-computed target id.
export function assertNoExistingDerivative(targetPath: string, targetId: string): void {
  if (existsSync(targetPath)) {
    throw new Error(`refusing to overwrite existing derivative at ${targetId}.md`);
  }
}

// Build the instruction for a new, re-angled derivative. Exported so the prompt's guardrails
// (extraction-first, voice.yaml, the target platform's angle + max_chars) are unit-testable.
export function duplicatePrompt(
  slug: string,
  sourceId: string,
  sourcePlatform: string,
  targetPlatform: string,
  targetId: string,
  sourceBody: string,
  targetMaxChars?: number,
): string {
  const angle = resolveAngle(targetPlatform);
  return [
    `Create ONE new content derivative for Muxin Li's content pipeline: a ${targetPlatform} post`,
    `adapted from an existing ${sourcePlatform || "?"} post. Do not run shell commands; write the one new file, then stop.`,
    ``,
    `Source post (content/${slug}/derivatives/${sourceId}.md, platform: ${sourcePlatform || "?"}):`,
    `"""`,
    sourceBody,
    `"""`,
    ``,
    `New file to write: content/${slug}/derivatives/${targetId}.md`,
    ``,
    `Write this exact frontmatter block, then the new post body:`,
    `---`,
    `platform: ${targetPlatform}`,
    `spin: true`,
    `angle: ${targetPlatform}`,
    `---`,
    ``,
    `Rules:`,
    `- Write ONLY that one new file. Touch nothing else — no other derivative, no review-queue.md.`,
    `- Extraction-first: the body must stay traceable to Muxin's source at content/${slug}/source.md —`,
    `  reframe and re-hook for ${targetPlatform}'s audience, but NEVER invent a claim, statistic,`,
    `  metaphor, or worldview Muxin did not express in the source post above.`,
    angle ? `- ${targetPlatform}'s approved angle (audience: ${angle.audience}): ${angle.angle}` : ``,
    `- Follow config/voice.yaml: no em dashes, no AI tells, Muxin's plain PM voice.`,
    targetMaxChars ? `- Stay within ${targetPlatform}'s ${targetMaxChars}-character limit.` : ``,
    `- Be surgical: this is a re-angling of the source post for a new audience, not a new essay.`,
  ]
    .filter(Boolean)
    .join("\n");
}

// Duplicate one existing text derivative into a NEW derivative for `targetPlatform`, respun via
// the existing spin angle, and append its review-queue.md row (status `pending`) so it lands back
// in the Review tab. Routed through runQueued like every other Claude spawn in this GUI.
export async function duplicateToPlatform(
  slug: string,
  id: string,
  targetPlatform: string,
  engine: Engine = "claude",
): Promise<{ id: string; platform: string; body: string }> {
  const folder = safeFolder(slug);
  if (!/^[\w.-]+$/.test(id)) throw new Error("bad id");
  if (!TEXT_PLATFORMS.has(targetPlatform)) {
    throw new Error(`"${targetPlatform}" isn't a platform this can duplicate to`);
  }
  const p = join(folder, "derivatives", `${id}.md`);
  if (!existsSync(p)) throw new Error("no such derivative to duplicate");
  const { fm, body } = splitFrontmatter(readFileSync(p, "utf8"));
  const sourcePlatform = typeof fm.platform === "string" ? fm.platform : "";
  const maxChars = loadPlatforms().platforms[targetPlatform]?.max_chars;

  return runQueued("duplicate", `Duplicate ${slug}/${id} to ${targetPlatform}`, async (job) => {
    // Computed at RUN time, not enqueue time: the queue serializes one job at a time, so reading
    // review-queue.md for the next free id HERE (not before the job was even queued) can't race
    // with another duplicate/atomize job that lands in between and claims the same id.
    const targetId = nextDerivativeId(folder, targetPlatform);
    const targetPath = join(folder, "derivatives", `${targetId}.md`);
    assertNoExistingDerivative(targetPath, targetId);
    const prompt = duplicatePrompt(slug, id, sourcePlatform, targetPlatform, targetId, body, maxChars);

    const result = await runClaudeSpawn(job, prompt, { timeoutMs: REVISE_TIMEOUT_MS });
    const failure = decodeSpawnFailure(result, job.id, {
      timeoutVerb: `${engineName(job)} duplicate`, timeoutLabel: `${REVISE_TIMEOUT_MS / 1000}s`,
      exitVerb: `${engineName(job)} duplicate`, command: job.engine === "claude" ? undefined : ENGINE_COMMANDS[job.engine ?? "claude"],
    });
    if (failure) throw new Error(failure);
    if (!existsSync(targetPath)) {
      throw new Error(`${engineName(job)} ran but didn't write ${targetId}.md — check the view-log link${logTailSuffix(job.id)}`);
    }

    const newBody = splitFrontmatter(readFileSync(targetPath, "utf8")).body;
    stampFileEngine(targetPath, engine);
    appendRow(folder, {
      id: targetId,
      platform: targetPlatform,
      format: "text",
      asset: `derivatives/${targetId}.md`,
      status: "pending",
      notes: `duplicated from ${id} for ${targetPlatform}`,
      origin: "from GUI queue",
    });
    return { id: targetId, platform: targetPlatform, body: newBody };
  }, engine);
}

// ── Follow-ups tab: "Draft follow-up" ────────────────────────────────────────────────────────
// A follow-up touch is a Spin reframe of the already-locked message, extraction-first (plan §5
// stage 9) — this reuses outreach/draft.ts's runDraft() (the ONE place composed prose is allowed,
// c308a8cf/CLAUDE.md rule 1's scoped exception) verbatim, never a bespoke compose path. Routed
// through the SAME job queue every other GUI Claude spawn uses, so it's bounded by the one
// `draining` mutex. Writes a new messages/message-NN.md + a `pending` review-queue.md row — same
// as any other draft — nothing here sends or locks anything (CLAUDE.md rule 2 analog).
//
// Card d39258ab: runDraft's default callClaudeDraft spawns via execFile, so this job used to get
// no persisted log or heartbeat despite being routed through the shared queue — unlike every other
// Claude-spawning GUI action. Fix: inject a callClaude backed by the shared runClaudeSpawn/
// decodeSpawnFailure so it gets a real log + heartbeat too, WITHOUT changing what gets generated —
// same model (draftModel(), the same resolver draft.ts's own callClaudeDraft uses), same --tools ""
// lockdown, same prompt, same timeout as draft.ts's own execFile call. Only transport + error
// wording differ.
//
// NO `STEP` MARKERS on this job, deliberately. runDraft takes the spawn's stdout AS THE MESSAGE
// BODY, so a `STEP 1/3 ...` line would land inside messages/message-NN.md. It is one step anyway;
// the lastStdoutLine heartbeat is the whole progress story.
const DRAFT_TIMEOUT_MS = 120_000; // mirrors outreach/draft.ts's own (private) DRAFT_TIMEOUT_MS

// The ONE queued-draft path, shared by Follow-ups' "Draft follow-up" and the Outreach thread's
// directed first draft. Only the label and the optional typed direction differ; the transport,
// model, tools lockdown and timeout stay identical so neither caller can drift from the other.
export interface OutreachDraftJobDeps {
  /** Injectable only for focused tests; production keeps the existing runDraft path. */
  runDraft?: typeof runDraft;
  /** Injectable only for focused tests; production uses the shared engine-aware spawn. */
  spawn?: typeof runClaudeSpawn;
}

export function enqueueOutreachDraft(
  label: string,
  dir: string,
  opts: { channel?: string; recipient?: string; direction?: string },
  engine: Engine = "claude",
  deps: OutreachDraftJobDeps = {},
): Promise<DraftResult> {
  const draft = deps.runDraft ?? runDraft;
  const spawn = deps.spawn ?? runClaudeSpawn;
  return runQueued("draft-follow-up", label, (job) =>
    draft(dir, {
      channel: opts.channel,
      recipient: opts.recipient,
      direction: opts.direction,
      callClaude: async (prompt) => {
        const result = await spawn(job, prompt, {
          timeoutMs: DRAFT_TIMEOUT_MS,
          model: draftModel(),
          tools: "",
          permissionMode: null,
        });
        const failure = decodeSpawnFailure(result, job.id, {
          timeoutVerb: `${engineName(job)} draft`,
          timeoutLabel: "120s",
          exitVerb: `${engineName(job)} draft`,
          includeTailOnTimeout: true,
          command: ENGINE_COMMANDS[job.engine ?? "claude"],
        });
        if (failure) throw new Error(failure);
        const text = result.stdout.trim();
        if (!text) throw new Error(`${engineName(job)} returned no text during draft`);
        return text;
      },
    }),
    engine,
  );
}

export async function enqueueFollowUpDraft(
  dir: string,
  channel?: string,
  recipient?: string,
  engine: Engine = "claude",
): Promise<DraftResult> {
  return enqueueOutreachDraft(`Draft follow-up: ${dir}`, dir, { channel, recipient }, engine);
}

// ── Outreach thread: the directed first draft (v7 handoff §3, the conversational half) ───────
// Muxin types what she wants said, and that text rides into THIS run's draft prompt (see
// buildDraftPrompt's direction block). It wins over the stored pitch_angle where they disagree,
// because pitch_angle is what research.ts concluded upstream and the typed direction is what she
// wants now. Iterating on the result is NOT here: it reuses the existing reviseOutreachMessage /
// POST /api/outreach/message/revise path, so there is exactly one revise path in this codebase.
export async function enqueueDirectedDraft(
  dir: string,
  channel?: string,
  recipient?: string,
  direction?: string,
  engine: Engine = "claude",
  deps: OutreachDraftJobDeps = {},
): Promise<DraftResult> {
  return enqueueOutreachDraft(`Draft message: ${dir}`, dir, { channel, recipient, direction }, engine, deps);
}

// ── Charles room: "Draft" (Build 4) ─────────────────────────────────────────────────────────
// The Charles room's missing front door — parity with the Content room's "Format directly", which
// spawns the real /atomize headlessly. This does the same for /charles: one bounded claude -p call
// that writes exactly one new draft file + appends exactly one review-queue.md row, then stops.
// Text modes only (one-liner/essay/reply) — memes are out of scope here on purpose (Muxin does
// meme research/image-gen elsewhere); the Charles room instead offers a one-click copy of
// charles/config/persona-brief.md for her to hand to whatever tool she's using for that.
const CHARLES_DRAFT_TIMEOUT_MS = 240_000;
export type CharlesDraftMode = "oneliner" | "essay" | "reply";
const CHARLES_DRAFT_MODES = new Set<CharlesDraftMode>(["oneliner", "essay", "reply"]);

// Exported so the prompt's guardrails (persona.yaml governs the voice, not config/voice.yaml;
// leak-bank-only claims; exactly one file + one queue row; id uniqueness) are unit-testable
// without spawning a real subprocess.
export function charlesDraftPrompt(mode: CharlesDraftMode, input: string, existingIds: string[]): string {
  const inputLine =
    mode === "reply"
      ? `Reply to this real post/article — fetch it first, never invent what it said: ${input}`
      : input.trim()
        ? `Topic/angle to draft toward: ${input.trim()}`
        : `No specific topic given — pick one of the comic-engine angles yourself.`;
  const dirByMode: Record<CharlesDraftMode, string> = {
    oneliner: "one-liners", essay: "essays", reply: "replies",
  };
  return [
    `Draft ONE new post for Charles Lord Featherbottom, a fictional satirical persona in this repo`,
    `(Build 4). Do not run shell commands beyond what reading/writing files requires; write the one`,
    `new file plus the one queue row below, then stop.`,
    ``,
    `First read charles/CLAUDE.md and charles/config/persona.yaml in full — his voice is governed`,
    `by persona.yaml, NOT config/voice.yaml. Then follow the "Mode: /charles ${mode}" section of`,
    `.claude/skills/charles/SKILL.md exactly, for this input:`,
    ``,
    inputLine,
    ``,
    `Rules:`,
    `- Write ONLY the one new draft file (under charles/posts/${dirByMode[mode]}/)`,
    `  plus ONE new row appended to charles/review-queue.md. Touch nothing else.`,
    `- Pick a short kebab-case id/slug for the draft that is NOT already one of these existing ids:`,
    `  ${existingIds.length ? existingIds.join(", ") : "(none yet)"}`,
    `- Status for the new row is always "pending" — never approve/discard it yourself.`,
    `- If you use a "useful leak," it MUST be one already listed in persona.yaml's leak_bank —`,
    `  never invent a statistic, org, or ballot measure that isn't there.`,
    `- Keep the em-dash ban (charles/CLAUDE.md carries it over from Build 2's fiction rule).`,
  ].join("\n");
}

export async function enqueueCharlesDraft(mode: string, input: string, engine: Engine = "claude"): Promise<{ id: string; post: CharlesPost }> {
  if (!CHARLES_DRAFT_MODES.has(mode as CharlesDraftMode)) {
    throw new Error(`"${mode}" isn't a mode this can draft from the GUI — try one-liner, essay, or reply`);
  }
  if (mode === "reply" && !input.trim()) throw new Error("a reply needs a URL to react to");

  return runQueued("charles-draft", `Draft a Charles ${mode}`, async (job) => {
    const before = new Set(listCharlesPosts(CHARLES_DIR).map((p) => p.id));
    const prompt = charlesDraftPrompt(mode as CharlesDraftMode, input, [...before]);

    const result = await runClaudeSpawn(job, prompt, { timeoutMs: CHARLES_DRAFT_TIMEOUT_MS });
    const failure = decodeSpawnFailure(result, job.id, {
      timeoutVerb: `${engineName(job)} draft`, timeoutLabel: `${CHARLES_DRAFT_TIMEOUT_MS / 1000}s`,
      exitVerb: `${engineName(job)} draft`, command: job.engine === "claude" ? undefined : ENGINE_COMMANDS[job.engine ?? "claude"],
    });
    if (failure) throw new Error(failure);

    const after = listCharlesPosts(CHARLES_DIR);
    const newId = after.map((p) => p.id).find((id) => !before.has(id));
    if (!newId) {
      throw new Error(`${engineName(job)} ran but didn't add a new row to charles/review-queue.md — check the view-log link${logTailSuffix(job.id)}`);
    }
    stampCharlesEngine(newId, job.engine ?? "claude", CHARLES_DIR);
    return { id: newId, post: readCharlesPost(newId, CHARLES_DIR) };
  }, engine);
}
